<?php
// Heading
$_['heading_title']  = 'Seo Urls';

// Texts
$_['text_edit']      = 'Edit Seo Urls Module';
$_['text_module']      = 'Modules';
$_['text_extension']   = 'Extensions';

$_['entry_url']   = 'Url';
$_['entry_route']   = 'Route';
$_['entry_status']  = 'Status:';

$_['text_enabled']  = 'Enabled';
$_['text_disabled'] = 'Disabled';

// Buttons
$_['button_save']  = 'Save';
$_['button_cancel']  = 'Cancel';
$_['button_add']  = 'Add New';
$_['button_delete']  = 'Delete';

// Success
$_['text_success']  = 'Success: You have modified module Seo Urls!';
$_['text_success_delete'] = 'Success! The selected route has been deleted!';

// Errors
$_['error_permission'] = 'Warning: You do not have permission to modify Seo Urls module!';
$_['error_url_route']  = 'Please specify correct route and url!';
$_['error_route']      = 'Warning: This route is already used!';
$_['error_keyword']    = 'Warning: This keyword is already used!!';
