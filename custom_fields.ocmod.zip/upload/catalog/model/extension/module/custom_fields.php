<?php
class ModelExtensionModuleCustomFields extends Model
{
	private $table_field = DB_PREFIX . "add_field";
	private $table_field_label = DB_PREFIX . "add_field_label";
	private $table_field_option = DB_PREFIX . "add_field_option";
	private $table_field_option_value = DB_PREFIX . "add_field_option_value";
	private $table_field_product_langvalue = DB_PREFIX . "add_field_product_langvalue";
	private $table_field_product_value = DB_PREFIX . "add_field_product_value";

	public function getField($field_id)
	{
		$query = $this->db->query("SELECT * FROM " . $this->table_field . " WHERE field_id = '" . (int)$field_id . "'");
		$query_options = $this->db->query("SELECT * FROM " . $this->table_field_option . " WHERE field_id = '" . (int)$field_id . "'");
		$options = array();
		foreach ($query_options->rows as $key => $row) {
			$options[$key] = $row;
			$query_values = $this->db->query("SELECT * FROM " . $this->table_field_option_value . " WHERE option_id = '" . (int)$row['option_id'] . "'");
			$options[$key]['value'] = array();
			foreach ($query_values->rows as $row2) {
				$options[$key]['value'][$row2['language_id']] = $row2['value'];
			}
		}
		return [
			'field_id' => $query->row['field_id'],
			'input_html' => $query->row['input_html'],
			'input_name' => $query->row['input_name'],
			'db_type' => $query->row['db_type'],
			'db_type_length' => $query->row['db_type_length'],
			'required' => $query->row['required'],
			'status' => $query->row['status'],
			'sort_order' => $query->row['sort_order'],
			'options' => $options,
		];
	}

	public function getFields($data = array())
	{
		$sql = "SELECT * FROM " . $this->table_field . " ag LEFT JOIN " . $this->table_field_label . " agd ON (ag.field_id = agd.field_id) WHERE agd.language_id = '" . (int)$this->config->get('config_language_id') . "'";

		$sort_data = array(
			'agd.label',
			'ag.sort_order'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY agd.label";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);
		$result = array();
		foreach ($query->rows as $row) {
			$query_options = $this->db->query("SELECT * FROM " . $this->table_field_option . " WHERE field_id = '" . (int)$row['field_id'] . "'");
			$options = array();
			foreach ($query_options->rows as $key => $row_option) {
				$options[$key] = $row_option;
				$query_values = $this->db->query("SELECT * FROM " . $this->table_field_option_value . " WHERE option_id = '" . (int)$row_option['option_id'] . "'");
				$options[$key]['value'] = array();
				foreach ($query_values->rows as $row_value) {
					$options[$key]['value'][$row_value['language_id']] = $row_value['value'];
				}
			}

			$result[] = [
				'field_id' => $row['field_id'],
				'input_html' => $row['input_html'],
				'input_name' => $row['input_name'],
				'db_type' => $query->row['db_type'],
				'db_type_length' => $query->row['db_type_length'],
				'required' => $row['required'],
				'status' => $row['status'],
				'sort_order' => $row['sort_order'],
				'label' => $row['label'],
				'options' => $options,
			];
		}
		return $result;
	}

	public function getFieldLabels($field_id)
	{
		$field_data = array();

		$query = $this->db->query("SELECT * FROM " . $this->table_field_label . " WHERE field_id = '" . (int)$field_id . "'");

		foreach ($query->rows as $result) {
			$field_data[$result['language_id']] = array('label' => $result['label']);
		}

		return $field_data;
	}


	public function getValue($link, $link_id)
	{
		$language_id = (int)$this->config->get('config_language_id');
		if ($link === 'product') {
			$query_lang = $this->db->query("SELECT * FROM " . $this->table_field_product_langvalue . " WHERE product_id = '" . (int)$link_id . "' AND language_id = '" . $language_id . "'");
			$query = $this->db->query("SELECT * FROM " . $this->table_field_product_value . " WHERE product_id = '" . (int)$link_id . "'");
			$result = array();
			$row_lang = $query_lang->row;
			$row = $query->row;
			if (count($row_lang) <= 0 && count($row) <= 0) {
				return [];
			}
			$query_fields = $this->db->query("SELECT * FROM " . $this->table_field . " WHERE status = 1");
			foreach ($query_fields->rows as $field) {
				if ($field['multilang']) {
					$data = $row_lang;
				} else {
					$data = $row;
				}
				if (!isset($data[$field['input_name']])) {
					continue;
				}
				$query_options = $this->db->query("SELECT * FROM " . $this->table_field_option . " WHERE field_id = '" . (int)$field['field_id'] . "'");
				$options = array();
				foreach ($query_options->rows as $key => $row_option) {
					$options[$row_option['option_id']] = '';
					$query_values = $this->db->query("SELECT * FROM " . $this->table_field_option_value . " WHERE option_id = '" . (int)$row_option['option_id'] . "' AND language_id = '" . $language_id . "'");
					foreach ($query_values->rows as $row_value) {
						$options[$row_option['option_id']] = $row_value['value'];
					}
				}
				if ($field['input_html'] == 'select' || $field['input_html'] == 'radio') {
					$result[$field['input_name']] = $options[$data[$field['input_name']]];
				} elseif ($field['input_html'] == 'wysiwyg') {
					$result[$field['input_name']] = html_entity_decode($data[$field['input_name']], ENT_QUOTES, 'UTF-8');
				} elseif ($field['input_html'] == 'checkbox') {
					$items = json_decode($data[$field['input_name']], true);
					$result[$field['input_name']] = array();
					foreach ($items as $key => $value) {
						$result[$field['input_name']][$key] = $options[$value];
					}
				} else {
					$result[$field['input_name']] = $data[$field['input_name']];
				}
			}
			return $result;
		}
		return [];
	}
}
