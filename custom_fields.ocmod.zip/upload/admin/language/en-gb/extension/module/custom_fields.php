<?php
// Heading
$_['heading_title']     = 'Custom Fields';

// Text
$_['text_success']         = 'Success: You have modified custom fields!';
$_['text_list']            = 'Custom Field List';
$_['text_add']             = 'Add Custom Field';
$_['text_edit']            = 'Edit Custom Field';
$_['text_choose']          = 'Choose';
$_['text_select']          = 'Select';
$_['text_radio']           = 'Radio';
$_['text_checkbox']        = 'Checkbox';
$_['text_input']           = 'Input';
$_['text_text']            = 'Text';
$_['text_textarea']        = 'Textarea';
$_['text_wysiwyg']         = 'Wysiwyg';
$_['text_account']         = 'Account';
$_['text_address']         = 'Address';
$_['text_affiliate']       = 'Affiliate';
$_['text_custom_field']    = 'Custom Field';
$_['text_value']           = 'Custom Field Values';
$_['text_extension']       = 'Extensions';

// Column
$_['column_label']      = 'Field Name';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Sort Order';
$_['column_action']     = 'Action';

// Entry
$_['entry_label']          = 'Custom Field Name';
$_['entry_input_html']     = 'HTML Element';
$_['entry_input_name']     = 'Input name';
$_['entry_db_type']        = 'Input type';
$_['entry_db_type_length'] = 'Input length';
$_['entry_label']          = 'Label';
$_['entry_custom_value']   = 'Custom Field Value Name';
$_['entry_status']         = 'Status';
$_['entry_multilang']      = 'Multi-language';
$_['entry_required']       = 'Required';
$_['entry_sort_order']     = 'Sort Order';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify custom fields!';
$_['error_label']       = 'Custom Field Name must be between 1 and 64 characters!';
$_['error_field']       = 'Warning: This custom field cannot be deleted as it is currently assigned to %s fields!';
