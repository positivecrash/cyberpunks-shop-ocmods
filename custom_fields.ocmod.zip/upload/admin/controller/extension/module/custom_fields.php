<?php
class ControllerExtensionModuleCustomFields extends Controller
{
	private $version = '0.0.1';
	private $error = array();

	public function index()
	{
		$this->load->language('extension/module/custom_fields');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('extension/module/custom_fields');

		$this->getList();
	}

	public function add()
	{
		$this->load->language('extension/module/custom_fields');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('extension/module/custom_fields');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_extension_module_custom_fields->addField($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('extension/module/custom_fields', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit()
	{
		$this->load->language('extension/module/custom_fields');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('extension/module/custom_fields');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_extension_module_custom_fields->editField($this->request->get['field_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('extension/module/custom_fields', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete()
	{
		$this->load->language('extension/module/custom_fields');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('extension/module/custom_fields');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $field_id) {
				$this->model_extension_module_custom_fields->deleteField($field_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('extension/module/custom_fields', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList()
	{
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'cfd.label';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = (int)$this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/custom_fields', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('extension/module/custom_fields/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('extension/module/custom_fields/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['fields'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$field_total = $this->model_extension_module_custom_fields->getTotalFields();

		$results = $this->model_extension_module_custom_fields->getFields($filter_data);

		foreach ($results as $result) {
			$data['fields'][] = array(
				'field_id'   => $result['field_id'],
				'label'      => $result['label'],
				'status'     => $result['status'],
				'sort_order' => $result['sort_order'],
				'edit'       => $this->url->link('extension/module/custom_fields/edit', 'user_token=' . $this->session->data['user_token'] . '&field_id=' . $result['field_id'] . $url, true)
			);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_label'] = $this->url->link('extension/module/custom_fields', 'user_token=' . $this->session->data['user_token'] . '&sort=cfd.label' . $url, true);
		$data['sort_status'] = $this->url->link('extension/module/custom_fields', 'user_token=' . $this->session->data['user_token'] . '&sort=cf.status' . $url, true);
		$data['sort_sort_order'] = $this->url->link('extension/module/custom_fields', 'user_token=' . $this->session->data['user_token'] . '&sort=cf.sort_order' . $url, true);

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $field_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('extension/module/custom_fields', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($field_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($field_total - $this->config->get('config_limit_admin'))) ? $field_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $field_total, ceil($field_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/custom_fields_list', $data));
	}

	protected function getForm()
	{
		$data['text_form'] = !isset($this->request->get['field_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['label'])) {
			$data['error_label'] = $this->error['label'];
		} else {
			$data['error_label'] = array();
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/custom_fields', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['field_id'])) {
			$data['action'] = $this->url->link('extension/module/custom_fields/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('extension/module/custom_fields/edit', 'user_token=' . $this->session->data['user_token'] . '&field_id=' . $this->request->get['field_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('extension/module/custom_fields', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['field_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$field_info = $this->model_extension_module_custom_fields->getField($this->request->get['field_id']);
		}

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		if (isset($this->request->post['field_label'])) {
			$data['field_label'] = $this->request->post['field_label'];
		} elseif (isset($this->request->get['field_id'])) {
			$data['field_label'] = $this->model_extension_module_custom_fields->getFieldLabels($this->request->get['field_id']);
		} else {
			$data['field_label'] = array();
		}

		if (isset($this->request->post['input_html'])) {
			$data['input_html'] = $this->request->post['input_html'];
		} elseif (!empty($field_info)) {
			$data['input_html'] = $field_info['input_html'];
		} else {
			$data['input_html'] = 'text';
		}

		if (isset($this->request->post['input_name'])) {
			$data['input_name'] = $this->request->post['input_name'];
		} elseif (!empty($field_info)) {
			$data['input_name'] = $field_info['input_name'];
		} else {
			$data['input_name'] = '';
		}

		if (isset($this->request->post['db_type'])) {
			$data['db_type'] = $this->request->post['db_type'];
		} elseif (!empty($field_info)) {
			$data['db_type'] = $field_info['db_type'];
		} else {
			$data['db_type'] = '';
		}

		if (isset($this->request->post['db_type_length'])) {
			$data['db_type_length'] = $this->request->post['db_type_length'];
		} elseif (!empty($field_info)) {
			$data['db_type_length'] = $field_info['db_type_length'];
		} else {
			$data['db_type_length'] = '128';
		}

		if (isset($this->request->post['options_edit'])) {
			$data['options_edit'] = $this->request->post['options_edit'];
		} elseif (!empty($field_info)) {
			$data['options_edit'] = $field_info['options'];
		} else {
			$data['options_edit'] = [];
		}

		if (isset($this->request->post['options_new'])) {
			$data['options_new'] = $this->request->post['options_new'];
		} else {
			$data['options_new'] = [];
		}

		if (isset($this->request->post['multilang'])) {
			$data['multilang'] = $this->request->post['multilang'];
		} elseif (!empty($field_info)) {
			$data['multilang'] = $field_info['multilang'];
		} else {
			$data['multilang'] = 0;
		}

		if (isset($this->request->post['required'])) {
			$data['required'] = $this->request->post['required'];
		} elseif (!empty($field_info)) {
			$data['required'] = $field_info['required'];
		} else {
			$data['required'] = 0;
		}

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($field_info)) {
			$data['status'] = $field_info['status'];
		} else {
			$data['status'] = '';
		}

		if (isset($this->request->post['sort_order'])) {
			$data['sort_order'] = $this->request->post['sort_order'];
		} elseif (!empty($field_info)) {
			$data['sort_order'] = $field_info['sort_order'];
		} else {
			$data['sort_order'] = '';
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/custom_fields_form', $data));
	}

	protected function validateForm()
	{
		if (!$this->user->hasPermission('modify', 'extension/module/custom_fields')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		foreach ($this->request->post['field_label'] as $language_id => $value) {
			if ((utf8_strlen($value['label']) < 1) || (utf8_strlen($value['label']) > 64)) {
				$this->error['label'][$language_id] = $this->language->get('error_label');
			}
		}

		return !$this->error;
	}

	protected function validateDelete()
	{
		if (!$this->user->hasPermission('modify', 'extension/module/custom_fields')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	protected function validate()
	{
		if (!$this->user->hasPermission('modify', 'extension/module/custom_fields')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	public function install()
	{
		$this->load->model('extension/module/custom_fields');
		$this->model_extension_module_custom_fields->install();
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('custom_fields');
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_custom_fields', array('module_custom_fields_status' => 1));
	}

	public function uninstall()
	{
		$this->load->model('extension/module/custom_fields');
		$this->model_extension_module_custom_fields->uninstall();
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('custom_fields');
	}
}
