<?php
class ModelExtensionModuleCustomFields extends Model
{
	private $table_field = DB_PREFIX . "add_field";
	private $table_field_label = DB_PREFIX . "add_field_label";
	private $table_field_option = DB_PREFIX . "add_field_option";
	private $table_field_option_value = DB_PREFIX . "add_field_option_value";
	private $table_field_product_langvalue = DB_PREFIX . "add_field_product_langvalue";
	private $table_field_product_value = DB_PREFIX . "add_field_product_value";

	public function addField($data)
	{
		if ($data['input_html'] == 'select' || $data['input_html'] == 'radio') {
			$data['db_type'] = 'INT';
			$data['db_type_length'] = 0;
		} elseif ($data['input_html'] == 'checkbox') {
			$data['db_type'] = 'VARCHAR';
			$data['db_type_length'] = 512;
		}

		$this->db->query("INSERT INTO " . $this->table_field . " SET
			input_html = '" . $this->db->escape($data['input_html']) . "',
			input_name = '" . $this->db->escape($data['input_name']) . "',
			db_type = '" . $this->db->escape($data['db_type']) . "',
			db_type_length = '" . (int)$data['db_type_length'] . "',
			multilang = '" . (isset($data['multilang']) ? 1 : 0) . "',
			required = '" . (isset($data['required']) ? 1 : 0) . "',
			status = '" . (int)$data['status'] . "',
			sort_order = '" . (int)$data['sort_order'] . "'
		");

		$field_id = $this->db->getLastId();

		// label
		foreach ($data['field_label'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . $this->table_field_label . " SET field_id = '" . (int)$field_id . "', language_id = '" . (int)$language_id . "', label = '" . $this->db->escape($value['label']) . "'");
		}

		// options
		if (isset($data['options_new'])) {
			foreach ($data['options_new'] as $option) {
				if (isset($data['multilang'])) {
					$this->db->query("INSERT INTO " . $this->table_field_option . " SET field_id = '" . $field_id . "', sort_order = '" . (int)$option['sort_order'] . "'");
					$option_id = $this->db->getLastId();
					foreach ($option['value'] as $language_id => $value) {
						$this->db->query("INSERT INTO " . $this->table_field_option_value . " SET option_id = '" . (int)$option_id . "', language_id = '" . (int)$language_id . "', `value` = '" . $this->db->escape($value) . "'");
					}
				} else {
					$this->db->query("INSERT INTO " . $this->table_field_option . " SET field_id = '" . $field_id . "', sort_order = '" . (int)$option['sort_order'] . "', `value` = '" . $this->db->escape($value) . "'");
				}
			}
		}

		// product
		$type = 'VARCHAR(256)';
		if ($data['db_type'] === 'VARCHAR') {
			$type = $data['db_type'] . "(" . (int)$data['db_type_length'] . ")";
		} else {
			$type = $data['db_type'];
		}

		$this->db->query("ALTER TABLE `" . $this->table_field_product_langvalue . "` ADD `" . $this->db->escape($data['input_name']) . "` " . $type . " NOT NULL");
		$this->db->query("ALTER TABLE `" . $this->table_field_product_value . "` ADD `" . $this->db->escape($data['input_name']) . "` " . $type . " NOT NULL");

		return $field_id;
	}

	public function editField($field_id, $data)
	{
		if ($data['input_html'] == 'select' || $data['input_html'] == 'radio') {
			$data['db_type'] = 'INT';
			$data['db_type_length'] = 0;
		} elseif ($data['input_html'] == 'checkbox') {
			$data['db_type'] = 'VARCHAR';
			$data['db_type_length'] = 512;
		}

		$query = $this->db->query("SELECT * FROM " . $this->table_field . " WHERE field_id = '" . (int)$field_id . "'");
		$column = $query->row['input_name'];
		$db_type = $query->row['db_type'];
		$db_type_length = $query->row['db_type_length'];

		$this->db->query("UPDATE " . $this->table_field . " SET
			input_html = '" . $this->db->escape($data['input_html']) . "',
			input_name = '" . $this->db->escape($data['input_name']) . "',
			db_type = '" . $this->db->escape($data['db_type']) . "',
			db_type_length = '" . (int)$data['db_type_length'] . "',
			multilang = '" . (isset($data['multilang']) ? 1 : 0) . "',
			required = '" . (isset($data['required']) ? 1 : 0) . "',
			status = '" . (int)$data['status'] . "',
			sort_order = '" . (int)$data['sort_order'] . "'
			WHERE field_id = '" . (int)$field_id . "'");

		// label
		$this->db->query("DELETE FROM " . $this->table_field_label . " WHERE field_id = '" . (int)$field_id . "'");
		foreach ($data['field_label'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . $this->table_field_label . " SET field_id = '" . (int)$field_id . "', language_id = '" . (int)$language_id . "', label = '" . $this->db->escape($value['label']) . "'");
		}

		// options
		if ($data['input_html'] == 'select' || $data['input_html'] == 'radio' || $data['input_html'] == 'checkbox') {
			$option_ids = array(0);
			if (isset($data['options_edit'])) {
				foreach ($data['options_edit'] as $option) {
					$option_ids[] = (int)$option['option_id'];
					if (isset($data['multilang'])) {
						$this->db->query("UPDATE " . $this->table_field_option . " SET sort_order = '" . (int)$option['sort_order'] . "', `value` = '' WHERE option_id = '" . (int)$option['option_id'] . "'");
						$this->db->query("DELETE FROM " . $this->table_field_option_value . " WHERE option_id = '" . (int)$option['option_id'] . "'");
						foreach ($option['value'] as $language_id => $value) {
							$this->db->query("INSERT INTO " . $this->table_field_option_value . " SET option_id = '" . (int)$option['option_id'] . "', language_id = '" . (int)$language_id . "', `value` = '" . $this->db->escape($value) . "'");
						}
					} else {
						$this->db->query("UPDATE " . $this->table_field_option . " SET sort_order = '" . (int)$option['sort_order'] . "', `value` = '" . $this->db->escape($option['value']) . "' WHERE option_id = '" . (int)$option['option_id'] . "'");
						$this->db->query("DELETE FROM " . $this->table_field_option_value . " WHERE option_id = '" . (int)$option['option_id'] . "'");
					}
				}
			}

			$query = $this->db->query("SELECT * FROM " . $this->table_field_option . " WHERE field_id = '" . (int)$field_id . "' AND option_id NOT IN (" . implode(", ", $option_ids) . ")");
			foreach ($query->rows as $option) {
				$this->db->query("DELETE FROM " . $this->table_field_option . " WHERE option_id = '" . (int)$option['option_id'] . "'");
				$this->db->query("DELETE FROM " . $this->table_field_option_value . " WHERE option_id = '" . (int)$option['option_id'] . "'");
			}

			if (isset($data['options_new'])) {
				foreach ($data['options_new'] as $option) {
					if (isset($data['multilang'])) {
						$this->db->query("INSERT INTO " . $this->table_field_option . " SET field_id = '" . $field_id . "', sort_order = '" . (int)$option['sort_order'] . "'");
						$option_id = $this->db->getLastId();
						foreach ($option['value'] as $language_id => $value) {
							$this->db->query("INSERT INTO " . $this->table_field_option_value . " SET option_id = '" . (int)$option_id . "', language_id = '" . (int)$language_id . "', `value` = '" . $this->db->escape($value) . "'");
						}
					} else {
						$this->db->query("INSERT INTO " . $this->table_field_option . " SET field_id = '" . $field_id . "', sort_order = '" . (int)$option['sort_order'] . "', `value` = '" . $this->db->escape($option['value']) . "'");
					}
				}
			}
		} else {
			$query = $this->db->query("SELECT * FROM " . $this->table_field_option . " WHERE field_id = '" . (int)$field_id . "'");
			foreach ($query->rows as $option) {
				$this->db->query("DELETE FROM " . $this->table_field_option . " WHERE option_id = '" . (int)$option['option_id'] . "'");
				$this->db->query("DELETE FROM " . $this->table_field_option_value . " WHERE option_id = '" . (int)$option['option_id'] . "'");
			}
		}

		// product
		if ($column !== $this->db->escape($data['input_name']) || $db_type !== $this->db->escape($data['db_type']) || $db_type_length !== $data['db_type_length']) {
			$type = 'VARCHAR(256)';
			if ($data['db_type'] === 'VARCHAR') {
				$type = $data['db_type'] . "(" . (int)$data['db_type_length'] . ")";
			} else {
				$type = $data['db_type'];
			}
			$this->db->query("ALTER TABLE `" . $this->table_field_product_langvalue . "` CHANGE `" . $column . "` `" . $this->db->escape($data['input_name']) . "` " . $type . " NOT NULL");
			$this->db->query("ALTER TABLE `" . $this->table_field_product_value . "` CHANGE `" . $column . "` `" . $this->db->escape($data['input_name']) . "` " . $type . " NOT NULL");
		}
	}

	public function deleteField($field_id)
	{
		$query = $this->db->query("SELECT * FROM " . $this->table_field . " WHERE field_id = '" . (int)$field_id . "'");
		$column = $query->row['input_name'];
		$this->db->query("DELETE FROM " . $this->table_field . " WHERE field_id = '" . (int)$field_id . "'");
		$this->db->query("DELETE FROM " . $this->table_field_label . " WHERE field_id = '" . (int)$field_id . "'");
		$query = $this->db->query("SELECT * FROM " . $this->table_field_option . " WHERE field_id = '" . (int)$field_id . "'");
		foreach ($query->rows as $option) {
			$this->db->query("DELETE FROM " . $this->table_field_option . " WHERE option_id = '" . (int)$option['option_id'] . "'");
			$this->db->query("DELETE FROM " . $this->table_field_option_value . " WHERE option_id = '" . (int)$option['option_id'] . "'");
		}
		$this->db->query("ALTER TABLE `" . $this->table_field_product_langvalue . "` DROP COLUMN `" . $column . "`");
		$this->db->query("ALTER TABLE `" . $this->table_field_product_value . "` DROP COLUMN `" . $column . "`");
	}

	public function getField($field_id)
	{
		$query = $this->db->query("SELECT * FROM " . $this->table_field . " WHERE field_id = '" . (int)$field_id . "'");
		$query_options = $this->db->query("SELECT * FROM " . $this->table_field_option . " WHERE field_id = '" . (int)$field_id . "'");
		$options = array();
		foreach ($query_options->rows as $key => $row) {
			$options[$key] = $row;
			if ($query->row['multilang']) {
				$query_values = $this->db->query("SELECT * FROM " . $this->table_field_option_value . " WHERE option_id = '" . (int)$row['option_id'] . "'");
				$options[$key]['value'] = array();
				foreach ($query_values->rows as $row2) {
					$options[$key]['value'][$row2['language_id']] = $row2['value'];
				}
			}
		}
		return [
			'field_id' => $query->row['field_id'],
			'input_html' => $query->row['input_html'],
			'input_name' => $query->row['input_name'],
			'db_type' => $query->row['db_type'],
			'db_type_length' => $query->row['db_type_length'],
			'multilang' => $query->row['multilang'],
			'required' => $query->row['required'],
			'status' => $query->row['status'],
			'sort_order' => $query->row['sort_order'],
			'options' => $options,
		];
	}

	public function getFields($data = array())
	{
		$sql = "SELECT * FROM " . $this->table_field . " cf LEFT JOIN " . $this->table_field_label . " cfd ON (cf.field_id = cfd.field_id) WHERE cfd.language_id = '" . (int)$this->config->get('config_language_id') . "'";

		if (isset($data['filter_status'])) {
			$sql .= " AND cf.status = 1";
		}

		$sort_data = array(
			'cfd.label',
			'cf.sort_order'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY cfd.label";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);
		$result = array();
		foreach ($query->rows as $row) {
			$query_options = $this->db->query("SELECT * FROM " . $this->table_field_option . " WHERE field_id = '" . (int)$row['field_id'] . "'");
			$options = array();
			foreach ($query_options->rows as $key => $row_option) {
				$options[$key] = $row_option;
				if ($row['multilang']) {
					$query_values = $this->db->query("SELECT * FROM " . $this->table_field_option_value . " WHERE option_id = '" . (int)$row_option['option_id'] . "'");
					$options[$key]['value'] = array();
					foreach ($query_values->rows as $row_value) {
						$options[$key]['value'][$row_value['language_id']] = $row_value['value'];
					}
				}
			}

			$result[] = [
				'field_id' => $row['field_id'],
				'input_html' => $row['input_html'],
				'input_name' => $row['input_name'],
				'db_type' => $query->row['db_type'],
				'db_type_length' => $query->row['db_type_length'],
				'multilang' => $row['multilang'],
				'required' => $row['required'],
				'status' => $row['status'],
				'sort_order' => $row['sort_order'],
				'label' => $row['label'],
				'options' => $options,
			];
		}
		return $result;
	}

	public function getFieldLabels($field_id)
	{
		$field_data = array();

		$query = $this->db->query("SELECT * FROM " . $this->table_field_label . " WHERE field_id = '" . (int)$field_id . "'");

		foreach ($query->rows as $result) {
			$field_data[$result['language_id']] = array('label' => $result['label']);
		}

		return $field_data;
	}

	public function getTotalFields()
	{
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . $this->table_field . "");

		return $query->row['total'];
	}

	public function getValue($link, $link_id)
	{
		if ($link === 'product') {
			$query_fields = $this->db->query("SELECT * FROM " . $this->table_field . "");
			$query_langvalue = $this->db->query("SELECT * FROM " . $this->table_field_product_langvalue . " WHERE product_id = '" . (int)$link_id . "'");
			$query_value = $this->db->query("SELECT * FROM " . $this->table_field_product_value . " WHERE product_id = '" . (int)$link_id . "'");
			$values = array();
			foreach ($query_fields->rows as $field) {
				if ($field['multilang']) {
					foreach ($query_langvalue->rows as $value) {
						$values[$field['field_id']][$value['language_id']] = $value[$field['input_name']];
					}
				} else if ($field['input_html'] == 'checkbox') {
					$values[$field['field_id']] = $query_value->num_rows > 0 ? json_decode($query_value->row[$field['input_name']], true) : '';
				} else {
					$values[$field['field_id']] = $query_value->num_rows > 0 ? $query_value->row[$field['input_name']] : '';
				}
			}
			return $values;
		}
		return [];
	}

	public function addFieldValue($link, $link_id, $data)
	{
		$query = $this->db->query("SELECT * FROM " . $this->table_field . " WHERE status = 1");
		if ($link === 'product') {
			$table_lang = $this->table_field_product_langvalue;
			$table = $this->table_field_product_value;
		} else {
			return;
		}
		$this->load->model('localisation/language');
		$languages = $this->model_localisation_language->getLanguages();
		$query_insert = array();
		$query_insert[0] = "INSERT INTO " . $table . " SET
			product_id = '" . (int)$link_id . "'
		";
		foreach ($languages as $language) {
			$query_insert[$language['language_id']] = "INSERT INTO " . $table_lang . " SET
				product_id = '" . (int)$link_id . "',
				language_id = '" . $language['language_id'] . "'
			";
		}
		foreach ($query->rows as $field) {
			if (!$field['multilang']) {
				if ($field['input_html'] == 'select') {
					$query_insert[0] .= ", `" . $field['input_name'] . "` = '" . (int)$data[$field['field_id']] . "'";
				} elseif ($field['input_html'] == 'radio') {
					$query_insert[0] .= ", `" . $field['input_name'] . "` = '" . (int)$data[$field['field_id']] . "'";
				} elseif ($field['input_html'] == 'checkbox') {
					$query_insert[0] .= ", `" . $field['input_name'] . "` = '" . json_encode($data[$field['field_id']]) . "'";
				} else {
					$query_insert[0] .= ", `" . $field['input_name'] . "` = '" . (
						isset($data[$field['field_id']]) ?
						$this->db->escape($data[$field['field_id']]) :
						''
					) . "'";
				}
			} else {
				foreach ($languages as $language) {
					if (!isset($data[$field['field_id']])) {
						continue;
					}
					if ($field['input_html'] == 'select') {
						$query_insert[$language['language_id']] .= ", `" . $field['input_name'] . "` = '" . (int)$data[$field['field_id']] . "'";
					} elseif ($field['input_html'] == 'radio') {
						$query_insert[$language['language_id']] .= ", `" . $field['input_name'] . "` = '" . (int)$data[$field['field_id']] . "'";
					} elseif ($field['input_html'] == 'checkbox') {
						$query_insert[$language['language_id']] .= ", `" . $field['input_name'] . "` = '" . json_encode($data[$field['field_id']]) . "'";
					} else {
						$query_insert[$language['language_id']] .= ", `" . $field['input_name'] . "` = '" . (
							isset($data[$field['field_id']][$language['language_id']]) ?
							$this->db->escape($data[$field['field_id']][$language['language_id']]) :
							''
						) . "'";
					}
				}
			}
		}
		foreach ($query_insert as $query) {
			$this->db->query($query);
		}
	}

	public function editFieldValue($link, $link_id, $data)
	{
		$this->deleteFieldValue($link, $link_id);
		$this->addFieldValue($link, $link_id, $data);
	}

	public function deleteFieldValue($link, $link_id)
	{
		if ($link === 'product') {
			$this->db->query("DELETE FROM " . $this->table_field_product_langvalue . " WHERE product_id = '" . (int)$link_id . "'");
			$this->db->query("DELETE FROM " . $this->table_field_product_value . " WHERE product_id = '" . (int)$link_id . "'");
		}
	}

	public function install()
	{
		$query = "CREATE TABLE IF NOT EXISTS `" . $this->table_field . "` (
			`field_id` int(11) NOT NULL AUTO_INCREMENT,
			`input_html` varchar(256) NOT NULL,
			`input_name` varchar(256) NOT NULL,
			`db_type` varchar(28) NOT NULL,
			`db_type_length` int(11) NOT NULL,
			`multilang` tinyint(1) NOT NULL DEFAULT 1,
			`required` tinyint(1) NOT NULL DEFAULT 0,
			`status` tinyint(1) NOT NULL DEFAULT 0,
			`sort_order` int(3) NOT NULL,
			PRIMARY KEY (`field_id`),
			UNIQUE KEY `input_name` (`input_name`)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;";
		$this->db->query($query);

		$query = "CREATE TABLE IF NOT EXISTS `" . $this->table_field_label . "` (
			`field_id` int(11) NOT NULL,
			`language_id` int(11) NOT NULL,
			`label` varchar(64) NOT NULL,
			PRIMARY KEY (`field_id`,`language_id`)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;";
		$this->db->query($query);

		$query = "CREATE TABLE IF NOT EXISTS `" . $this->table_field_option . "` (
			`option_id` int(11) NOT NULL AUTO_INCREMENT,
			`field_id` int(11) NOT NULL,
			`value` varchar(128) NOT NULL,
			`sort_order` int(3) NOT NULL,
			PRIMARY KEY (`option_id`)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;";
		$this->db->query($query);

		$query = "CREATE TABLE IF NOT EXISTS `" . $this->table_field_option_value . "` (
			`option_id` int(11) NOT NULL,
			`language_id` int(11) NOT NULL,
			`value` varchar(128) NOT NULL,
			PRIMARY KEY (`option_id`,`language_id`)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;";
		$this->db->query($query);

		$query = "CREATE TABLE IF NOT EXISTS `" . $this->table_field_product_langvalue . "` (
			`product_id` int(11) NOT NULL,
			`language_id` int(11) NOT NULL,
			PRIMARY KEY (`product_id`,`language_id`)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;";
		$this->db->query($query);

		$query = "CREATE TABLE IF NOT EXISTS `" . $this->table_field_product_value . "` (
			`product_id` int(11) NOT NULL,
			PRIMARY KEY (`product_id`)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;";
		$this->db->query($query);
	}

	public function uninstall()
	{
		$query = "DROP TABLE `" . $this->table_field . "`;";
		$this->db->query($query);
		$query = "DROP TABLE `" . $this->table_field_label . "`;";
		$this->db->query($query);
		$query = "DROP TABLE `" . $this->table_field_option . "`;";
		$this->db->query($query);
		$query = "DROP TABLE `" . $this->table_field_option_value . "`;";
		$this->db->query($query);
		$query = "DROP TABLE `" . $this->table_field_product_langvalue . "`;";
		$this->db->query($query);
		$query = "DROP TABLE `" . $this->table_field_product_value . "`;";
		$this->db->query($query);
	}
}
