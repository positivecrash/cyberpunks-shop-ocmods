<?php
$_['heading_title'] = 'Cyberpunks Variant Images';

$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified Cyberpunks Variant Images module!';
$_['text_edit'] = 'Edit Variant Image Mappings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';

$_['entry_status'] = 'Status';
$_['entry_product_id'] = 'Product ID';
$_['entry_signature'] = 'Variant Builder';
$_['entry_image'] = 'Image (catalog/...)';
$_['entry_mapping_status'] = 'Row Status';

$_['button_add_mapping'] = 'Add mapping';
$_['button_remove'] = 'Remove';
$_['button_add_option_pair'] = 'Add option';
$_['button_import'] = 'Import';

$_['help_signature'] = 'Select option + value pairs. Signature is generated automatically.';
$_['help_image'] = 'Use relative image path from image/ directory, example: catalog/products/altruist/cyan_green.jpg';
$_['help_import'] = 'File format: product_id + options map + image. Import replaces current mappings.';

$_['text_import_success'] = 'Import completed successfully.';

$_['error_permission'] = 'Warning: You do not have permission to modify Cyberpunks Variant Images module!';
$_['error_import_file_required'] = 'Import file is required.';
$_['error_import_file_empty'] = 'Import file is empty.';
$_['error_import_invalid_format'] = 'Import format is invalid.';
$_['error_import_no_rows'] = 'No valid import rows were found.';
