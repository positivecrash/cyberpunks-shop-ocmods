<?php
class ModelExtensionModuleCyberpunksMailTemplates extends Model {
	public function isEnabled() {
		return (bool)$this->config->get('module_cyberpunks_mail_templates_status');
	}

	public function getStatusCodes() {
		return array('paid', 'pending', 'processing', 'shipped', 'canceled', 'complete');
	}

	public function getTemplateHtml($code) {
		$templates = $this->config->get('module_cyberpunks_mail_templates_html');

		if (!is_array($templates)) {
			return '';
		}

		$code = (string)$code;

		if (!is_file(DIR_SYSTEM . 'library/cyberpunks_mail_html.php')) {
			return isset($templates[$code]) ? trim((string)$templates[$code]) : '';
		}

		require_once(DIR_SYSTEM . 'library/cyberpunks_mail_html.php');

		return isset($templates[$code]) ? trim(CyberpunksMailHtml::decodeStored((string)$templates[$code])) : '';
	}

	public function getSubject($code) {
		if (!$this->isEnabled()) {
			return '';
		}

		$subjects = $this->config->get('module_cyberpunks_mail_templates_subject');

		if (!is_array($subjects)) {
			return '';
		}

		$code = (string)$code;

		return isset($subjects[$code]) ? trim((string)$subjects[$code]) : '';
	}

	public function isTemplateEnabled($code) {
		if (!$this->isEnabled()) {
			return false;
		}

		$enabled = $this->config->get('module_cyberpunks_mail_templates_enabled');

		if (!is_array($enabled)) {
			return false;
		}

		return !empty($enabled[$code]) && $this->getTemplateHtml($code) !== '';
	}

	/**
	 * Resolve template code from OpenCart order_status_id (by status name).
	 */
	public function resolveStatusCode($order_status_id, $language_id = 0) {
		$order_status_id = (int)$order_status_id;

		if ($order_status_id < 1) {
			return '';
		}

		if ($language_id < 1) {
			$language_id = (int)$this->config->get('config_language_id');
		}

		$query = $this->db->query("SELECT `name` FROM `" . DB_PREFIX . "order_status` WHERE order_status_id = '" . (int)$order_status_id . "' AND language_id = '" . (int)$language_id . "' LIMIT 1");

		if (!$query->num_rows) {
			$query = $this->db->query("SELECT `name` FROM `" . DB_PREFIX . "order_status` WHERE order_status_id = '" . (int)$order_status_id . "' ORDER BY language_id ASC LIMIT 1");
		}

		if (!$query->num_rows) {
			return '';
		}

		return $this->statusNameToCode($query->row['name']);
	}

	public function statusNameToCode($name) {
		$key = strtolower(trim(html_entity_decode((string)$name, ENT_QUOTES, 'UTF-8')));
		$map = array(
			'paid'       => 'paid',
			'pending'    => 'pending',
			'processing' => 'processing',
			'shipped'    => 'shipped',
			'canceled'   => 'canceled',
			'cancelled'  => 'canceled',
			'complete'   => 'complete'
		);

		return isset($map[$key]) ? $map[$key] : '';
	}

	/**
	 * Apply subject + body for an order status customer email.
	 * Falls back to stock OpenCart mail when no custom subject/HTML for that status.
	 *
	 * @param object $mail
	 * @param string $route mail/order_add|mail/order_edit
	 * @param array  $data
	 * @param string $default_subject
	 * @param int    $order_status_id
	 * @param array  $order_info optional — used to enrich edit emails with products/totals
	 */
	public function applyOrderStatusMail($mail, $route, $data, $default_subject, $order_status_id, $order_info = array()) {
		$code = $this->resolveStatusCode($order_status_id, !empty($order_info['language_id']) ? (int)$order_info['language_id'] : 0);

		$custom_subject = ($code !== '') ? $this->getSubject($code) : '';
		$use_html = ($code !== '') && $this->isTemplateEnabled($code);

		if ($custom_subject === '' && !$use_html) {
			$mail->setSubject($default_subject);

			if ($route === 'mail/order_add') {
				$vars = $this->buildVariables($data);
				$body = $this->load->view('mail/order_add', $data);
				$html = $this->finalizeHtmlEmail($this->applyLayout($body, $vars, $code));
				$mail->setText('');
				$mail->setHtml($html);
			} else {
				$mail->setText($this->load->view('mail/order_edit', $data));
			}

			return;
		}

		if ($use_html && empty($data['products']) && !empty($order_info['order_id'])) {
			$data = $this->enrichOrderData($data, $order_info, $order_status_id);
		}

		$vars = $this->buildVariables($data);

		if ($custom_subject !== '') {
			$mail->setSubject(html_entity_decode($this->replaceShortcodes($custom_subject, $vars), ENT_QUOTES, 'UTF-8'));
		} else {
			$mail->setSubject($default_subject);
		}

		if ($use_html) {
			$body = $this->replaceShortcodes($this->getTemplateHtml($code), $vars);
			$html = $this->finalizeHtmlEmail($this->applyLayout($body, $vars, $code));
			$mail->setText('');
			$mail->setHtml($html);
			return;
		}

		if ($route === 'mail/order_add') {
			$body = $this->load->view('mail/order_add', $data);
			$html = $this->finalizeHtmlEmail($this->applyLayout($body, $vars, $code));
			$mail->setText('');
			$mail->setHtml($html);
		} else {
			$mail->setText($this->load->view('mail/order_edit', $data));
		}
	}

	public function getLayouts() {
		$layouts = $this->config->get('module_cyberpunks_mail_templates_layouts');

		return is_array($layouts) ? $layouts : array();
	}

	public function getLayoutById($layout_id) {
		$layout_id = (string)$layout_id;

		if ($layout_id === '') {
			return null;
		}

		foreach ($this->getLayouts() as $layout) {
			if (!is_array($layout) || empty($layout['id'])) {
				continue;
			}

			if ((string)$layout['id'] === $layout_id) {
				return $layout;
			}
		}

		return null;
	}

	public function getLayoutIdForStatus($status_code) {
		$map = $this->config->get('module_cyberpunks_mail_templates_layout');

		if (!is_array($map) || $status_code === '') {
			return '';
		}

		return isset($map[$status_code]) ? trim((string)$map[$status_code]) : '';
	}

	/**
	 * Wrap status/stock body in the layout chosen for this status ({content} shortcode).
	 */
	private function applyLayout($body_html, array $vars, $status_code) {
		if (!$this->isEnabled() || $status_code === '') {
			return $body_html;
		}

		$layout = $this->getLayoutById($this->getLayoutIdForStatus($status_code));

		if (!$layout || !isset($layout['html']) || trim((string)$layout['html']) === '') {
			return $body_html;
		}

		if (!is_file(DIR_SYSTEM . 'library/cyberpunks_mail_html.php')) {
			$html = str_replace('{content}', $body_html, (string)$layout['html']);

			return $this->replaceShortcodes($html, $vars);
		}

		require_once(DIR_SYSTEM . 'library/cyberpunks_mail_html.php');

		$html = str_replace('{content}', $body_html, CyberpunksMailHtml::decodeStored((string)$layout['html']));

		return $this->replaceShortcodes($html, $vars);
	}

	private function finalizeHtmlEmail($html) {
		if (!is_file(DIR_SYSTEM . 'library/cyberpunks_mail_html.php')) {
			return (string)$html;
		}

		require_once(DIR_SYSTEM . 'library/cyberpunks_mail_html.php');

		return CyberpunksMailHtml::normalizeDocument($html, true);
	}

	private function replaceShortcodes($text, array $vars) {
		foreach ($vars as $key => $value) {
			$text = str_replace('{' . $key . '}', (string)$value, $text);
		}

		return $text;
	}

	private function buildVariables(array $data) {
		$store_name = isset($data['store_name']) ? $data['store_name'] : $this->config->get('config_name');
		$comment = $this->normalizeComment(isset($data['comment']) ? $data['comment'] : '');

		return array(
			'store_name'       => $store_name,
			'store_url'        => isset($data['store_url']) ? $data['store_url'] : HTTP_SERVER,
			'logo'             => isset($data['logo']) ? $data['logo'] : '',
			'email'            => isset($data['email']) ? $data['email'] : '',
			'telephone'        => isset($data['telephone']) ? $data['telephone'] : '',
			'ip'               => isset($data['ip']) ? $data['ip'] : '',
			'link'             => isset($data['link']) ? $data['link'] : '',
			'download'         => isset($data['download']) ? $data['download'] : '',
			'order_id'         => isset($data['order_id']) ? $data['order_id'] : '',
			'date_added'       => isset($data['date_added']) ? $data['date_added'] : '',
			'order_status'     => isset($data['order_status']) ? $data['order_status'] : '',
			'payment_method'   => isset($data['payment_method']) ? $data['payment_method'] : '',
			'shipping_method'  => isset($data['shipping_method']) ? $data['shipping_method'] : '',
			'payment_address'  => isset($data['payment_address']) ? $data['payment_address'] : '',
			'shipping_address' => isset($data['shipping_address']) ? $data['shipping_address'] : '',
			'comment'          => $this->formatCommentHtml($comment),
			'greeting'         => isset($data['text_greeting']) ? $data['text_greeting'] : '',
			'firstname'        => isset($data['firstname']) ? $data['firstname'] : '',
			'lastname'         => isset($data['lastname']) ? $data['lastname'] : '',
			'products_table'   => $this->renderProductsTable($data),
			'products_cards'   => $this->renderProductsCards($data),
			'totals_table'     => $this->renderTotalsTable($data),
		);
	}

	/**
	 * Plain text from Add History → Comment (Notify Customer).
	 * Decodes admin Request::clean() entities and strips tags.
	 */
	private function normalizeComment($comment) {
		$comment = html_entity_decode((string)$comment, ENT_QUOTES, 'UTF-8');
		$comment = strip_tags($comment);
		$comment = preg_replace("/\r\n|\r/", "\n", $comment);

		return trim((string)$comment);
	}

	private function formatCommentHtml($comment) {
		$comment = $this->normalizeComment($comment);

		if ($comment === '') {
			return '';
		}

		return nl2br(htmlspecialchars($comment, ENT_QUOTES, 'UTF-8'), false);
	}

	/**
	 * Fill products / totals / addresses when status-update mail only had thin $data.
	 */
	private function enrichOrderData(array $data, array $order_info, $order_status_id) {
		if (!isset($this->model_checkout_order)) {
			$this->load->model('checkout/order');
		}

		if (!isset($this->model_tool_upload)) {
			$this->load->model('tool/upload');
		}

		$language = new Language($order_info['language_code']);
		$language->load($order_info['language_code']);
		$language->load('mail/order_add');

		if (empty($data['store_name'])) {
			$data['store_name'] = $order_info['store_name'];
		}
		if (empty($data['store_url'])) {
			$data['store_url'] = $order_info['store_url'];
		}
		if (empty($data['logo'])) {
			$data['logo'] = $order_info['store_url'] . 'image/' . $this->config->get('config_logo');
		}
		if (empty($data['email'])) {
			$data['email'] = $order_info['email'];
		}
		if (empty($data['telephone'])) {
			$data['telephone'] = $order_info['telephone'];
		}
		if (empty($data['ip'])) {
			$data['ip'] = $order_info['ip'];
		}
		if (empty($data['payment_method'])) {
			$data['payment_method'] = $order_info['payment_method'];
		}
		if (empty($data['shipping_method'])) {
			$data['shipping_method'] = $order_info['shipping_method'];
		}
		if (empty($data['date_added'])) {
			$data['date_added'] = date($language->get('date_format_short'), strtotime($order_info['date_added']));
		}
		if (empty($data['firstname'])) {
			$data['firstname'] = $order_info['firstname'];
		}
		if (empty($data['lastname'])) {
			$data['lastname'] = $order_info['lastname'];
		}

		$data['text_product'] = $language->get('text_product');
		$data['text_model'] = $language->get('text_model');
		$data['text_quantity'] = $language->get('text_quantity');
		$data['text_price'] = $language->get('text_price');
		$data['text_total'] = $language->get('text_total');

		if (empty($data['payment_address'])) {
			$data['payment_address'] = $this->formatAddress($order_info, 'payment');
		}
		if (empty($data['shipping_address'])) {
			$data['shipping_address'] = $this->formatAddress($order_info, 'shipping');
		}

		$order_products = $this->model_checkout_order->getOrderProducts($order_info['order_id']);
		$data['products'] = array();

		foreach ($order_products as $order_product) {
			$option_data = array();
			$order_options = $this->model_checkout_order->getOrderOptions($order_info['order_id'], $order_product['order_product_id']);

			foreach ($order_options as $order_option) {
				if ($order_option['type'] != 'file') {
					$value = $order_option['value'];
				} else {
					$upload_info = $this->model_tool_upload->getUploadByCode($order_option['value']);
					$value = $upload_info ? $upload_info['name'] : '';
				}

				$option_data[] = array(
					'name'  => $order_option['name'],
					'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
				);
			}

			$data['products'][] = array(
				'product_id' => $order_product['product_id'],
				'name'     => $order_product['name'],
				'model'    => $order_product['model'],
				'option'   => $option_data,
				'quantity' => $order_product['quantity'],
				'price'    => $this->currency->format($order_product['price'] + ($this->config->get('config_tax') ? $order_product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
				'total'    => $this->currency->format($order_product['total'] + ($this->config->get('config_tax') ? ($order_product['tax'] * $order_product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value'])
			);
		}

		$data['vouchers'] = array();
		foreach ($this->model_checkout_order->getOrderVouchers($order_info['order_id']) as $order_voucher) {
			$data['vouchers'][] = array(
				'description' => $order_voucher['description'],
				'amount'      => $this->currency->format($order_voucher['amount'], $order_info['currency_code'], $order_info['currency_value'])
			);
		}

		$data['totals'] = array();
		foreach ($this->model_checkout_order->getOrderTotals($order_info['order_id']) as $order_total) {
			$data['totals'][] = array(
				'title' => $order_total['title'],
				'text'  => $this->currency->format($order_total['value'], $order_info['currency_code'], $order_info['currency_value'])
			);
		}

		return $data;
	}

	private function formatAddress(array $order_info, $prefix) {
		$format = !empty($order_info[$prefix . '_address_format'])
			? $order_info[$prefix . '_address_format']
			: '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';

		$find = array('{firstname}', '{lastname}', '{company}', '{address_1}', '{address_2}', '{city}', '{postcode}', '{zone}', '{zone_code}', '{country}');
		$replace = array(
			'firstname' => $order_info[$prefix . '_firstname'],
			'lastname'  => $order_info[$prefix . '_lastname'],
			'company'   => $order_info[$prefix . '_company'],
			'address_1' => $order_info[$prefix . '_address_1'],
			'address_2' => $order_info[$prefix . '_address_2'],
			'city'      => $order_info[$prefix . '_city'],
			'postcode'  => $order_info[$prefix . '_postcode'],
			'zone'      => $order_info[$prefix . '_zone'],
			'zone_code' => $order_info[$prefix . '_zone_code'],
			'country'   => $order_info[$prefix . '_country']
		);

		return str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));
	}

	private function renderProductsTable(array $data) {
		$products = isset($data['products']) && is_array($data['products']) ? $data['products'] : array();
		$vouchers = isset($data['vouchers']) && is_array($data['vouchers']) ? $data['vouchers'] : array();

		if (!$products && !$vouchers) {
			return '';
		}

		$label_product = isset($data['text_product']) ? $data['text_product'] : 'Product';
		$label_model = isset($data['text_model']) ? $data['text_model'] : 'Model';
		$label_qty = isset($data['text_quantity']) ? $data['text_quantity'] : 'Qty';
		$label_price = isset($data['text_price']) ? $data['text_price'] : 'Price';
		$label_total = isset($data['text_total']) ? $data['text_total'] : 'Total';

		$html = '<table style="border-collapse:collapse;width:100%;border-top:1px solid #ddd;border-left:1px solid #ddd;margin-bottom:20px;">';
		$html .= '<thead><tr>';
		$html .= $this->th($label_product);
		$html .= $this->th($label_model);
		$html .= $this->th($label_qty, 'right');
		$html .= $this->th($label_price, 'right');
		$html .= $this->th($label_total, 'right');
		$html .= '</tr></thead><tbody>';

		foreach ($products as $product) {
			$name = isset($product['name']) ? $product['name'] : '';
			$options = '';

			if (!empty($product['option']) && is_array($product['option'])) {
				foreach ($product['option'] as $option) {
					$options .= '<br /><small> - ' . htmlspecialchars($option['name'], ENT_QUOTES, 'UTF-8') . ': ' . htmlspecialchars($option['value'], ENT_QUOTES, 'UTF-8') . '</small>';
				}
			}

			$html .= '<tr>';
			$html .= $this->td(htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . $options);
			$html .= $this->td(isset($product['model']) ? htmlspecialchars($product['model'], ENT_QUOTES, 'UTF-8') : '');
			$html .= $this->td(isset($product['quantity']) ? (int)$product['quantity'] : '', 'right');
			$html .= $this->td(isset($product['price']) ? $product['price'] : '', 'right');
			$html .= $this->td(isset($product['total']) ? $product['total'] : '', 'right');
			$html .= '</tr>';
		}

		foreach ($vouchers as $voucher) {
			$html .= '<tr>';
			$html .= $this->td(isset($voucher['description']) ? htmlspecialchars($voucher['description'], ENT_QUOTES, 'UTF-8') : '');
			$html .= $this->td('');
			$html .= $this->td('1', 'right');
			$html .= $this->td(isset($voucher['amount']) ? $voucher['amount'] : '', 'right');
			$html .= $this->td(isset($voucher['amount']) ? $voucher['amount'] : '', 'right');
			$html .= '</tr>';
		}

		$html .= '</tbody></table>';

		return $html;
	}

	private function renderProductsCards(array $data) {
		$products = isset($data['products']) && is_array($data['products']) ? $data['products'] : array();

		if (!$products) {
			return '';
		}

		if (!isset($this->model_catalog_product)) {
			$this->load->model('catalog/product');
		}

		if (!isset($this->model_tool_image)) {
			$this->load->model('tool/image');
		}

		$store_url = isset($data['store_url']) ? rtrim($data['store_url'], '/') . '/' : HTTP_SERVER;
		$html = '';

		foreach ($products as $product) {
			$name = isset($product['name']) ? htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8') : '';
			$qty = isset($product['quantity']) ? (int)$product['quantity'] : 0;
			$image = '';

			if (!empty($product['product_id'])) {
				$product_info = $this->model_catalog_product->getProduct((int)$product['product_id']);

				if (!empty($product_info['image'])) {
					$image = $this->model_tool_image->resize($product_info['image'], 100, 100);

					if ($image && strpos($image, 'http') !== 0) {
						$image = $store_url . ltrim($image, '/');
					}
				}
			}

			$options_html = '';

			if (!empty($product['option']) && is_array($product['option'])) {
				foreach ($product['option'] as $option) {
					$options_html .= htmlspecialchars($option['name'], ENT_QUOTES, 'UTF-8') . ': '
						. htmlspecialchars($option['value'], ENT_QUOTES, 'UTF-8') . '<br />';
				}
			}

			$html .= '<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom:16px;">';
			$html .= '<tr>';
			$html .= '<td width="72" valign="top" style="padding-right:16px;">';

			if ($image) {
				$html .= '<img src="' . htmlspecialchars($image, ENT_QUOTES, 'UTF-8') . '" width="64" height="64" alt="" style="width:64px;height:64px;display:block;border:2px solid #000000;" />';
			} else {
				$html .= '<div style="width:64px;height:64px;border:2px solid #000000;background-color:#f5f5f5;font-size:0;line-height:0;">&nbsp;</div>';
			}

			$html .= '</td>';
			$html .= '<td valign="top" style="font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:22px;color:#000000;">';
			$html .= '<strong style="font-weight:700;">' . $name . '</strong><br />';

			if ($options_html !== '') {
				$html .= '<span style="font-size:14px;line-height:20px;color:#333333;">' . $options_html . '</span>';
			}

			$html .= '<span style="font-size:14px;line-height:20px;">Qty: ' . $qty . '</span>';
			$html .= '</td></tr></table>';
		}

		return $html;
	}

	private function renderTotalsTable(array $data) {
		$totals = isset($data['totals']) && is_array($data['totals']) ? $data['totals'] : array();

		if (!$totals) {
			return '';
		}

		$html = '<table style="border-collapse:collapse;width:100%;border-top:1px solid #ddd;border-left:1px solid #ddd;margin-bottom:20px;"><tbody>';

		foreach ($totals as $total) {
			$html .= '<tr>';
			$html .= '<td style="font-size:12px;border-right:1px solid #ddd;border-bottom:1px solid #ddd;text-align:right;padding:7px;"><b>' . htmlspecialchars(isset($total['title']) ? $total['title'] : '', ENT_QUOTES, 'UTF-8') . '</b></td>';
			$html .= '<td style="font-size:12px;border-right:1px solid #ddd;border-bottom:1px solid #ddd;text-align:right;padding:7px;width:20%;">' . (isset($total['text']) ? $total['text'] : '') . '</td>';
			$html .= '</tr>';
		}

		$html .= '</tbody></table>';

		return $html;
	}

	private function th($label, $align = 'left') {
		return '<td style="font-size:12px;border-right:1px solid #ddd;border-bottom:1px solid #ddd;background:#efefef;font-weight:bold;text-align:' . $align . ';padding:7px;color:#222;">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</td>';
	}

	private function td($value, $align = 'left') {
		return '<td style="font-size:12px;border-right:1px solid #ddd;border-bottom:1px solid #ddd;text-align:' . $align . ';padding:7px;">' . $value . '</td>';
	}
}
