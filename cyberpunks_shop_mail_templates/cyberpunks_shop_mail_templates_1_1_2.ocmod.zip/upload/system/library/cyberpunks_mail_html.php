<?php
class CyberpunksMailHtml {
	const HTML_OPEN = '<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">';

	public static function decodeStored($html) {
		$html = (string)$html;
		$prev = null;

		while ($prev !== $html && (strpos($html, '&lt;') !== false || strpos($html, '&gt;') !== false || strpos($html, '&amp;') !== false)) {
			$prev = $html;
			$html = html_entity_decode($html, ENT_QUOTES, 'UTF-8');
		}

		return $html;
	}

	public static function isFullDocument($html) {
		$html = ltrim((string)$html);

		return (bool)preg_match('/<!DOCTYPE\s+html/i', $html) || (bool)preg_match('/<html[\s>]/i', $html);
	}

	/**
	 * Wrap partial markup in a valid HTML email document.
	 * Restores structure when Summernote (or similar) stripped DOCTYPE/html/head/body.
	 */
	public static function normalizeDocument($html, $force_wrap = true) {
		$html = trim(self::decodeStored($html));

		if ($html === '') {
			return '';
		}

		if (self::isFullDocument($html)) {
			return $html;
		}

		if (!$force_wrap) {
			return $html;
		}

		$head = '';
		$body = $html;

		if (preg_match('/^((?:\s|<!--(?:.(?!-->))*-->|<meta\b[^>]*>|<title\b[^>]*>.*?<\/title>|<link\b[^>]*>|<style\b[^>]*>.*?<\/style>)+)([\s\S]*)$/is', $html, $matches)) {
			$head = trim($matches[1]);
			$body = trim($matches[2]);

			if ($body === '') {
				$body = $head;
				$head = '<meta charset="utf-8">';
			}
		} else {
			$head = '<meta charset="utf-8">';
		}

		if (!preg_match('/<meta\b[^>]*charset/i', $head)) {
			$head = '<meta charset="utf-8">' . "\n" . $head;
		}

		return '<!DOCTYPE html>' . "\n"
			. self::HTML_OPEN . "\n"
			. '<head>' . "\n" . $head . "\n" . '</head>' . "\n"
			. '<body>' . "\n" . $body . "\n" . '</body>' . "\n"
			. '</html>';
	}

	/**
	 * Email clients cannot resolve site-relative paths like /catalog/... — rewrite to absolute.
	 */
	public static function absolutizeUrls($html, $base_url) {
		$base = rtrim((string)$base_url, '/');

		if ($base === '') {
			return (string)$html;
		}

		return preg_replace_callback(
			'/\b(src|href|background)=(["\'])(\/[^"\']*)\2/i',
			function ($m) use ($base) {
				return $m[1] . '=' . $m[2] . $base . $m[3] . $m[2];
			},
			(string)$html
		);
	}

	/**
	 * Plain-text alternative for multipart/alternative (OpenCart inserts a scary
	 * "does not support HTML email" stub when setText is empty).
	 */
	public static function htmlToPlainText($html) {
		$text = self::decodeStored($html);
		$text = preg_replace('/<style\b[^>]*>.*?<\/style>/is', '', $text);
		$text = preg_replace('/<script\b[^>]*>.*?<\/script>/is', '', $text);
		$text = preg_replace('/<(br|hr)\s*\/?>/i', "\n", $text);
		$text = preg_replace('/<\/(p|div|h[1-6]|tr|li|table)>/i', "\n", $text);
		$text = strip_tags($text);
		$text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
		$text = preg_replace("/[ \t\x0B\f]+/", ' ', $text);
		$text = preg_replace("/ ?\n ?/", "\n", $text);
		$text = preg_replace("/\n{3,}/", "\n\n", $text);

		$text = trim($text);

		if ($text === '') {
			return 'Please view this message in an HTML-capable email client.';
		}

		return $text;
	}
}
