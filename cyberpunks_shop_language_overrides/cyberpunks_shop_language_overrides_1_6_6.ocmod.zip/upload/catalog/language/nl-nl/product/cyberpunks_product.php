<?php
// Product page UI (theme) — Dutch stubs
$_['text_add_to_cart']       = 'In winkelwagen';
$_['text_cart_updated']      = 'Winkelwagen bijgewerkt';
$_['text_buy_now']           = 'Nu kopen';
$_['text_buy_now_aria']      = 'Nu kopen — %s';
$_['text_from']              = 'Vanaf';
$_['text_in_stock']          = 'Op voorraad';
$_['text_availability_in_stock'] = 'Beschikbaarheid: Op voorraad';
$_['text_buy_on']            = 'KOOP OP';
$_['text_buy_on_amazon']     = 'Kopen op Amazon';
$_['text_free']              = 'GRATIS';
$_['text_pricing_info']      = 'Prijsinformatie';
$_['text_current_price']     = 'Huidige prijs: %s';
$_['text_original_price']    = 'Originele prijs: %s';
