<?php
// Shared theme UI (header banner, home)
$_['text_buy_now']                 = 'Buy now';
$_['text_banner_unique']           = 'Unique open-source smart hardware';
$_['text_banner_worldwide']        = 'Worldwide delivery';
$_['text_banner_made_eu']          = 'Made and shipped from the EU';
$_['text_banner_guarantee_years']  = '2-year';
$_['text_banner_guarantee']        = 'guarantee';
$_['text_home_slide_dual']         = 'Connect your sleep, HRV, and recovery metrics with real environmental conditions around your home using detailed air-quality, CO₂, noise, and climate analytics';
$_['text_home_slide_urban']        = 'Go beyond simplified AQI maps with real-time local air-quality monitoring, detailed timelines, and noise analytics';
$_['text_home_slide_insight']      = 'Altruist Insight is designed for precise and stable indoor CO₂ monitoring without false spikes caused by perfumes, cooking smells, candles, or other everyday VOC sources.';
$_['text_featured_products']       = 'Featured products';
$_['text_previous_slide']          = 'Previous slide';
$_['text_next_slide']              = 'Next slide';
$_['aria_site_announcements']      = 'Site announcements';
$_['aria_select_country']          = 'Select country';
$_['aria_language']                = 'Select language';
