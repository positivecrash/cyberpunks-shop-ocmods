<?php
// Product page UI (theme)
$_['text_add_to_cart']       = 'Add to Cart';
$_['text_cart_updated']      = 'Your cart updated';
$_['text_buy_now']           = 'Buy now';
$_['text_buy_now_aria']      = 'Buy now — %s';
$_['text_from']              = 'From';
$_['text_in_stock']          = 'In stock';
$_['text_availability_in_stock'] = 'Availability: In stock';
$_['text_buy_on']            = 'BUY ON';
$_['text_buy_on_amazon']     = 'Buy on Amazon';
$_['text_free']              = 'FREE';
$_['text_pricing_info']      = 'Pricing Information';
$_['text_current_price']     = 'Current price: %s';
$_['text_original_price']    = 'Original price: %s';
