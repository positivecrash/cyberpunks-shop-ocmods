<?php

/**
 * Creates minimal OpenCart language directories so a new language can be added
 * from admin without manually uploading packs.
 *
 * Only bootstraps {code}/{code}.php (+ optional flag png). Other route files
 * keep falling back to en-gb via Language::load().
 */
class CyberpunksLanguagePack {
	/**
	 * @param string $code Directory code, e.g. de-de, fr-fr, nl-nl
	 * @return bool True when stubs exist (created or already present)
	 */
	public static function ensureStub($code) {
		$code = strtolower(trim((string)$code));

		if (!self::isValidCode($code) || $code === 'en-gb' || $code === 'en') {
			return false;
		}

		$ok = true;
		$ok = self::ensureSide(DIR_CATALOG . 'language/', $code) && $ok;

		if (defined('DIR_APPLICATION')) {
			$ok = self::ensureSide(DIR_APPLICATION . 'language/', $code) && $ok;
		}

		return $ok;
	}

	public static function isValidCode($code) {
		return (bool)preg_match('/^[a-z]{2}(-[a-z]{2})?$/', (string)$code);
	}

	private static function ensureSide($language_root, $code) {
		$language_root = rtrim(str_replace('\\', '/', (string)$language_root), '/') . '/';
		$target_dir = $language_root . $code . '/';
		$source_dir = $language_root . 'en-gb/';

		if (!is_dir($source_dir) || !is_file($source_dir . 'en-gb.php')) {
			return false;
		}

		if (!is_dir($target_dir) && !@mkdir($target_dir, 0755, true) && !is_dir($target_dir)) {
			return false;
		}

		$target_php = $target_dir . $code . '.php';

		if (!is_file($target_php)) {
			$php = file_get_contents($source_dir . 'en-gb.php');

			if ($php === false) {
				return false;
			}

			$short = self::shortCode($code);
			$php = preg_replace(
				'/\\$_\\[\'code\'\\]\\s*=\\s*\'[^\']*\'\\s*;/',
				"\$_['code']                  = '" . $short . "';",
				$php,
				1
			);

			if (@file_put_contents($target_php, $php) === false) {
				return false;
			}
		}

		$target_png = $target_dir . $code . '.png';

		if (!is_file($target_png)) {
			$source_png = $source_dir . 'en-gb.png';

			if (is_file($source_png)) {
				@copy($source_png, $target_png);
			}
		}

		return is_file($target_php);
	}

	private static function shortCode($code) {
		$parts = explode('-', strtolower((string)$code));

		return isset($parts[0]) && $parts[0] !== '' ? $parts[0] : 'en';
	}
}
