<?php
$_['heading_title'] = 'Cyberpunks Language Overrides';

$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have updated language overrides.';
$_['text_edit'] = 'Edit Checkout Cart Strings';
$_['text_home'] = 'Home';
$_['text_override'] = 'Override';
$_['text_original'] = 'Original';
$_['text_key'] = 'Language Key';
$_['text_total_labels'] = 'Cart Total Labels';
$_['text_total_labels_help'] = 'Override order total labels by code for checkout cart rendering.';
$_['text_total_code'] = 'Total Code';

$_['text_checkout_placeholders'] = 'Checkout Placeholders';
$_['text_checkout_placeholders_help'] = 'Override checkout field placeholders / labels (keys from catalog/language/en-gb/checkout/checkout.php).';

$_['entry_override'] = 'Override Text';

$_['error_permission'] = 'Warning: You do not have permission to modify this module.';
