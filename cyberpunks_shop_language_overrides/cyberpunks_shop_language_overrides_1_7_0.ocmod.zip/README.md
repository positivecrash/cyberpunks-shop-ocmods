# Cyberpunks Shop Language Overrides

Dutch language pack, URL locales (`/en/`, `/nl/`), **cb_lang** theme strings (editable in admin), shared SEO keywords, hreflang / `og:locale`, cart total labels, thousand separator.

## Install

1. `./build-ocmod.sh cyberpunks_shop_language_overrides`
2. Upload `cyberpunks_shop_language_overrides_1_7_0.ocmod.zip`
3. Extensions → Modifications → **Refresh**
4. Open **Extensions → Modules → Cyberpunks Language Overrides** once (creates tables + seeds default strings)
5. Clear theme Twig cache if needed (`system/storage/cache/template/`)

## Theme translations: `cb_lang`

In Twig:

```twig
{{ cb_lang('Buy now') }}
{{ cb_lang('Buy now — %s', heading_title) }}
```

In PHP:

```php
cb_lang('Buy now');
cb_lang('Current price: %s', $price);
```

Lookup is by **exact** original string + current `config_language_id`. If no row / empty translation → original text is shown.

Admin: **Extensions → Modules → Cyberpunks Language Overrides**

| Field | Purpose |
|-------|---------|
| Original text | Must match `cb_lang('…')` in the theme exactly |
| Comment | Admin note (where used) |
| Translations | One field per storefront language |

First open of the module seeds common header/home/product strings (EN + NL).

## SEO keywords (same slug for all languages)

Same keyword across languages is allowed; uniqueness is per store + language. Decode filters by `language_id`.

## URL locale

| File | Role |
|------|------|
| `catalog/controller/extension/module/cyberpunks_locale.php` | `early` / `late` |
| `system/library/cyberpunks_url_locale.php` | helpers |
| `system/library/cyberpunks_language_switcher.php` | language select `href`s |
| `system/library/cyberpunks_cb_lang.php` | `cb_lang` + Twig registration |
| `system/config/catalog.php` (OCMOD) | registers locale pre-actions |
| `system/library/template/twig.php` (OCMOD) | registers Twig `cb_lang` |

## After refresh

Check `ocmod.log` — no `NOT FOUND` for `catalog.php`, `twig.php`, SEO uniqueness, or locale lines.
