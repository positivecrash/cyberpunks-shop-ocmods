<?php

class CyberpunksLanguageOverrides {
	/** @deprecated Key-map overrides removed in 1.7.0 — theme strings use cb_lang. */
	public static function apply($language, $filename, $config) {
	}
}
