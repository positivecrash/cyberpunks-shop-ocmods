# Cyberpunks Shop Language Overrides

Dutch pack, URL locales (`/en/`, `/nl/`), hreflang / `og:locale`, theme UI strings, admin overrides, cart totals, thousand separator.

## Install

1. `./build-ocmod.sh cyberpunks_shop_language_overrides`
2. Upload `cyberpunks_shop_language_overrides_1_6_3.ocmod.zip`
3. Modifications → **Refresh**
4. Open the storefront — URL should become `/en/` or `/nl/`

## How URL locale works

OpenCart OCMOD only matches **single-line** searches. Multi-line patches for `seo_url` / `startup` were skipped (see `ocmod.log` → `NOT FOUND`).

Installer also blocks writes outside a whitelist — so the locale controller lives under `catalog/controller/extension/module/` (allowed), not `catalog/controller/startup/`.

| File | Role |
|------|------|
| `catalog/controller/extension/module/cyberpunks_locale.php` | `early` peels `/nl` from `_route_`; `late` prefixes links + redirects |
| `system/library/cyberpunks_url_locale.php` | helpers |
| `system/library/cyberpunks_language_switcher.php` | language select `href`s |
| `system/config/catalog.php` (OCMOD) | registers `extension/module/cyberpunks_locale/early` + `late` |

## After refresh, check `ocmod.log`

You should **not** see `NOT FOUND` for `cyberpunks_locale` / `catalog.php` lines. If `FILE: system/config/catalog.php` is missing, Refresh again after re-upload.
