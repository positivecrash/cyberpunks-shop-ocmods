# Cyberpunks Shop Language Overrides

Minimal Dutch core (`nl-nl.php`), URL locales (`/en/`, `/nl/`), **cb_lang** theme strings (admin), shared SEO keywords, hreflang / `og:locale`, cart totals, thousand separator.

## Install

1. `./build-ocmod.sh cyberpunks_shop_language_overrides`
2. Upload `cyberpunks_shop_language_overrides_1_7_3.ocmod.zip`
3. Extensions → Modifications → **Refresh**
4. Open **Extensions → Modules → Cyberpunks Language Overrides** once (tables + seed)
5. Clear Twig cache if needed: `system/storage/cache/template/`

## Why so few `nl-nl` files?

OpenCart `Language::load()` always loads **en-gb first**, then overlays `nl-nl` if the file exists. Missing Dutch files → English. Theme copy goes through `cb_lang` in admin, not PHP language packs.

Kept:

| Path | Why |
|------|-----|
| `catalog/language/nl-nl/nl-nl.php` (+ png) | language bootstrap / formats |
| `admin/language/nl-nl/nl-nl.php` (+ png) | optional Dutch admin |
| `admin/.../cyberpunks_language_overrides.php` | this module’s admin UI |

## Two kinds of text

1. **Theme Strings (cb_lang)** — marketing / theme UI. Add yourself. Original = EN.
2. **OpenCart Language Overrides** — stock keys from `checkout/cart`, `checkout/checkout`, `error/not_found`, checkout facade. Same map as before (`route:key`).

## Theme translations: `cb_lang`

```twig
{{ cb_lang('Buy now') }}
{{ cb_lang('Buy now — %s', heading_title) }}
```

Exact original string + current language. No translation → original text.

Admin: **Extensions → Modules → Cyberpunks Language Overrides** — original, comment, per-language translations.

## URL locale / SEO

Same as 1.6.x: `/en/` `/nl/`, shared SEO keywords across languages, hreflang.

## After refresh

`ocmod.log` should not show `NOT FOUND` for `twig.php` / `catalog.php`. Do **not** use a leading `\` before class names in OCMOD XML — OpenCart strips it and breaks namespaced files like `Template\Twig`. Use `call_user_func(array('CyberpunksCbLang', ...))` instead.
