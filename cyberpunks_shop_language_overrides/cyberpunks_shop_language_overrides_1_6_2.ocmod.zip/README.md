# Cyberpunks Shop Language Overrides

Dutch pack, URL locales (`/en/`, `/nl/`), hreflang / `og:locale`, theme UI strings, admin overrides, cart totals, thousand separator.

## Install

1. `./build-ocmod.sh cyberpunks_shop_language_overrides`
2. Upload `cyberpunks_shop_language_overrides_1_6_2.ocmod.zip`
3. Modifications → **Refresh**
4. Open the storefront — URL should become `/en/` or `/nl/`

## How URL locale works

OpenCart OCMOD only matches **single-line** searches. Multi-line patches for `seo_url` / `startup` were skipped (see `ocmod.log` → `NOT FOUND`).

Locale logic lives in uploaded files instead:

| File | Role |
|------|------|
| `catalog/controller/startup/cyberpunks_locale.php` | `early` peels `/nl` from `_route_`; `late` prefixes links + redirects |
| `system/library/cyberpunks_url_locale.php` | helpers |
| `system/library/cyberpunks_language_switcher.php` | language select `href`s |
| `system/config/catalog.php` (OCMOD) | registers the two startup actions |

## After refresh, check `ocmod.log`

You should **not** see `NOT FOUND` for `cyberpunks_locale` / `catalog.php` lines. If `FILE: system/config/catalog.php` is missing, Refresh again after re-upload.
