<?php

class CyberpunksLanguageSwitcher {
	public static function build($controller, $results) {
		$languages = array();

		if (!$controller || !is_array($results)) {
			return $languages;
		}

		$url_data = $controller->request->get;
		unset($url_data['_route_'], $url_data['language']);

		if (!isset($url_data['route'])) {
			$route = 'common/home';
			$query = '';
		} else {
			$route = $url_data['route'];
			unset($url_data['route']);
			$query = $url_data ? urldecode(http_build_query($url_data, '', '&')) : '';
		}

		$prev_code = isset($controller->session->data['language']) ? $controller->session->data['language'] : '';
		$prev_id = $controller->config->get('config_language_id');

		foreach ($results as $result) {
			if (empty($result['status'])) {
				continue;
			}

			$controller->session->data['language'] = $result['code'];
			$controller->config->set('config_language_id', (int)$result['language_id']);

			$languages[] = array(
				'name' => $result['name'],
				'code' => $result['code'],
				'href' => str_replace('&amp;', '&', $controller->url->link($route, $query, !empty($controller->request->server['HTTPS'])))
			);
		}

		$controller->session->data['language'] = $prev_code;
		$controller->config->set('config_language_id', $prev_id);

		return $languages;
	}
}
