# Cyberpunks Shop Language Overrides

Module + OCMOD for managing storefront language strings, cart total labels, and price formatting from admin.

## What this module includes

- Admin page grouped by catalog language file (`checkout/cart`, `checkout/checkout`, `error/not_found`, checkout facade, …)
- Storefront overrides applied globally after each language file load (`system/engine/loader.php` + startup)
- Namespaced override keys: `route/to/file:key` (legacy bare keys from older saves still work)
- Cart total label overrides by code (cart, checkout facade, review data OCMODs)
- Storefront thousands separator for prices (`currency->format()`), applied on startup
- Overridden keys are sorted to top within each group
- Saves into `module_cyberpunks_language_overrides_*` settings

## Adding more language files

Edit `getCatalogLanguageFiles()` in `upload/admin/controller/extension/module/cyberpunks_language_overrides.php`.

Theme UI files shipped by `cyberpunks_shop_i18n` are already listed:

- `common/cyberpunks_theme` — header banner / home
- `product/cyberpunks_product` — product page buttons / stock / FREE

**Note:** override map is not per-locale — the same values apply after every language file load. Use `nl-nl` language files (via `cyberpunks_shop_i18n` pack) for Dutch translations; use this module for storefront copy overrides (typically EN).

## Install / update

1. Build: `./build-ocmod.sh cyberpunks_shop_language_overrides`
2. Upload the zip in Extensions → Installer (wait until upload finishes)
3. Refresh Modifications
4. Open: Extensions → Modules → Cyberpunks Language Overrides
5. For spaced thousands: Price Format → Thousands Separator → **Space (8 707)** → Save

If admin breaks with `Failed opening required ... cyberpunks_language_overrides.php` (Installer JSON error with `<`):

1. Copy `upload/system/library/cyberpunks_language_overrides.php` from this package into the store’s `system/library/` (missing upload artifact — OCMOD patch was already active).
2. Reload Admin → Installer should work again.
3. Install this zip (1.5.3+), then Refresh Modifications.

v1.5.3+: both `startup.php` and `loader.php` patches skip the helper until the library file exists (avoids chicken-and-egg on reinstall).
