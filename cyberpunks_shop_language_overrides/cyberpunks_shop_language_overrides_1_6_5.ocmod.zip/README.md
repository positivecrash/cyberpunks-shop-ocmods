# Cyberpunks Shop Language Overrides

Dutch pack, URL locales (`/en/`, `/nl/`), shared SEO keywords across languages, hreflang / `og:locale`, theme UI strings, admin overrides, cart totals, thousand separator.

## Install

1. `./build-ocmod.sh cyberpunks_shop_language_overrides`
2. Upload `cyberpunks_shop_language_overrides_1_6_5.ocmod.zip`
3. Modifications → **Refresh**
4. Open the storefront — URL should become `/en/` or `/nl/`

## SEO keywords (same slug for all languages)

Stock OpenCart rejects the same SEO keyword on EN and NL (“SEO URL must be unique!”). With `/en/` and `/nl/` prefixes that is unnecessary.

This OCMOD:

- Allows the **same keyword** on every language row in product / category / information / manufacturer
- Still blocks clashes **within the same language** (two products cannot both use `altruist-dual` in English)
- Resolves SEO decode by `language_id` so `/en/altruist-dual` and `/nl/altruist-dual` both work

Fill both language fields with the same slug (e.g. `altruist-dual`).

## Admin language flags

Product SEO rows use `admin/language/{code}/{code}.png`. The Dutch pack ships a real NL flag (`nl-nl.png`). After install, hard-refresh the admin page if the British flag is cached.

Optional: System → Localisation → Languages → Dutch → set Image to `nl-nl.png` (some admin screens use the DB `image` field).

## How URL locale works

OpenCart OCMOD only matches **single-line** searches. Multi-line patches for `seo_url` / `startup` were skipped (see `ocmod.log` → `NOT FOUND`).

Installer also blocks writes outside a whitelist — so the locale controller lives under `catalog/controller/extension/module/` (allowed), not `catalog/controller/startup/`.

| File | Role |
|------|------|
| `catalog/controller/extension/module/cyberpunks_locale.php` | `early` peels `/nl` from `_route_`; `late` prefixes links + redirects |
| `system/library/cyberpunks_url_locale.php` | helpers |
| `system/library/cyberpunks_language_switcher.php` | language select `href`s |
| `system/config/catalog.php` (OCMOD) | registers `extension/module/cyberpunks_locale/early` + `late` |

## After refresh, check `ocmod.log`

You should **not** see `NOT FOUND` for `cyberpunks_locale` / `catalog.php` / SEO uniqueness lines. If `FILE: system/config/catalog.php` is missing, Refresh again after re-upload.
