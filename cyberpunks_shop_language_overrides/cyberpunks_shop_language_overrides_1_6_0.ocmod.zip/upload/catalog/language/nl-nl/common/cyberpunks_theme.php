<?php
// Shared theme UI (header banner, home) — Dutch stubs
$_['text_buy_now']                 = 'Nu kopen';
$_['text_banner_unique']           = 'Unieke open-source smart hardware';
$_['text_banner_worldwide']        = 'Wereldwijde levering';
$_['text_banner_made_eu']          = 'Gemaakt en verzonden vanuit de EU';
$_['text_banner_guarantee_years']  = '2 jaar';
$_['text_banner_guarantee']        = 'Garantie';
$_['text_home_slide_dual']         = 'Koppel je slaap-, HRV- en herstelmetrics aan echte omgevingsomstandigheden rondom je huis met gedetailleerde lucht-, CO₂-, geluids- en klimaatanalyses';
$_['text_home_slide_urban']        = 'Ga verder dan vereenvoudigde AQI-kaarten met realtime lokale luchtkwaliteitsmonitoring, gedetailleerde tijdlijnen en geluidsanalyses';
$_['text_home_slide_insight']      = 'Altruist Insight is ontworpen voor nauwkeurige en stabiele indoor CO₂-meting zonder valse pieken door parfums, kookluchtjes, kaarsen of andere alledaagse VOC-bronnen.';
$_['text_featured_products']       = 'Uitgelichte producten';
$_['text_previous_slide']          = 'Vorige slide';
$_['text_next_slide']              = 'Volgende slide';
$_['aria_site_announcements']      = 'Site-aankondigingen';
$_['aria_select_country']          = 'Selecteer land';
$_['aria_language']                = 'Taal';
