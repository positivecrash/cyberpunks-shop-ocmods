<?php

class CyberpunksUrlLocale {
	public static function shortFromCode($code) {
		$parts = explode('-', strtolower((string)$code));

		return isset($parts[0]) ? $parts[0] : '';
	}

	public static function codeFromShort($short, $languages) {
		$short = strtolower((string)$short);

		if ($short === '' || !is_array($languages)) {
			return '';
		}

		foreach ($languages as $code => $language) {
			if (empty($language['status'])) {
				continue;
			}

			if (self::shortFromCode($code) === $short) {
				return $code;
			}
		}

		return '';
	}

	/**
	 * Read /en|/nl from SEO _route_ into request language, then strip it for seo_url.
	 */
	public static function consumeRouteLocale($request, $languages) {
		if (!isset($request->get['_route_'])) {
			return;
		}

		$route = trim((string)$request->get['_route_'], '/');

		if ($route === '') {
			unset($request->get['_route_']);

			return;
		}

		$parts = explode('/', $route);
		$code = self::codeFromShort($parts[0], $languages);

		if ($code === '') {
			return;
		}

		$request->get['language'] = $code;
		array_shift($parts);

		if ($parts) {
			$request->get['_route_'] = implode('/', $parts);
		} else {
			unset($request->get['_route_']);
		}
	}

	/**
	 * Prefix storefront URL with /{short}/ (en, nl, …). Idempotent if already prefixed.
	 */
	public static function applyPrefix($link, $code) {
		$short = self::shortFromCode($code);

		if ($short === '') {
			return $link;
		}

		$url_info = parse_url(str_replace('&amp;', '&', (string)$link));

		if (empty($url_info['scheme']) || empty($url_info['host'])) {
			return $link;
		}

		$path = isset($url_info['path']) ? $url_info['path'] : '/';
		$path_trim = trim($path, '/');
		$first = ($path_trim === '') ? '' : explode('/', $path_trim)[0];

		if (strtolower($first) === $short) {
			return $link;
		}

		if (preg_match('#^(.*)/index\.php$#', $path, $match)) {
			$new_path = $match[1] . '/' . $short . '/index.php';
		} elseif ($path === '' || $path === '/') {
			$new_path = '/' . $short . '/';
		} elseif (substr($path, -1) === '/') {
			$new_path = '/' . $short . '/' . ltrim($path, '/');
		} else {
			$new_path = '/' . $short . $path;
		}

		$out = $url_info['scheme'] . '://' . $url_info['host'];

		if (!empty($url_info['port'])) {
			$out .= ':' . $url_info['port'];
		}

		$out .= $new_path;

		if (!empty($url_info['query'])) {
			$out .= '?' . str_replace('&', '&amp;', $url_info['query']);
		}

		if (!empty($url_info['fragment'])) {
			$out .= '#' . $url_info['fragment'];
		}

		return $out;
	}
}
