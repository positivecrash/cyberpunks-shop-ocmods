# Cyberpunks Shop Language Overrides

One language OCMOD: Dutch pack, URL locales (`/en/`, `/nl/`), hreflang / `og:locale`, theme UI strings, admin string overrides, cart total labels, price thousands separator.

## Install / update

1. Build: `./build-ocmod.sh cyberpunks_shop_language_overrides`
2. Upload `cyberpunks_shop_language_overrides_1_6_0.ocmod.zip` → Extensions → Installer
3. Refresh Modifications
4. If Dutch is new: System → Localisation → Languages → Add (`nl-nl`, locale `nl_NL.UTF-8,nl_NL,nl-NL,dutch`, Enabled)
5. Deploy theme from `github-templates/` (language switcher + header hreflang tags)

If you previously installed `cyberpunks_shop_i18n`, disable/remove that modification and use only this package (Refresh after).

## What’s included

| Piece | Role |
|-------|------|
| `upload/catalog/language/nl-nl/**` + `admin/language/nl-nl/**` | Dutch language pack (Installer copies folders) |
| `upload/catalog/language/{en-gb,nl-nl}/common/cyberpunks_theme.php` | Header banner / home UI |
| `upload/catalog/language/{en-gb,nl-nl}/product/cyberpunks_product.php` | Product page UI |
| `upload/system/library/cyberpunks_url_locale.php` | `/en|/nl` parse + URL prefix |
| `upload/system/library/cyberpunks_language_overrides.php` | Admin override map apply |
| Admin module | Edit overrides / total labels / thousand separator |

## Admin overrides

Extensions → Modules → Cyberpunks Language Overrides

Groups include theme files `common/cyberpunks_theme` and `product/cyberpunks_product`. Override map is **not** per-locale (same values for all languages) — use `nl-nl` files for Dutch translations.

## URL locales

- `en-gb` → `/en/…`, `nl-nl` → `/nl/…`
- Language select uses per-locale `href` for the current page
- Hreflang uses the same prefixed URLs

Do **not** hand-edit `docker-bundle/docker/www/` for packs or libraries — install via this zip.
