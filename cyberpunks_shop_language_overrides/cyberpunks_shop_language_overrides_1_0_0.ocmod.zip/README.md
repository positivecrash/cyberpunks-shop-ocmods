# Cyberpunks Shop Language Overrides

Small OCMOD for overriding selected storefront language strings without editing core files.

## Current overrides

- `catalog/language/en-gb/checkout/cart.php`
  - `error_stock` -> `Some items are not available in the requested quantity.`

## Customize

Edit `install.xml` and change replacement text in the relevant operation.
