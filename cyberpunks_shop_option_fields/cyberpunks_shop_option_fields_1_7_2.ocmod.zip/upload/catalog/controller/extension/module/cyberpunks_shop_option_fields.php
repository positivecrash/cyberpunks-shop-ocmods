<?php
class ControllerExtensionModuleCyberpunksShopOptionFields extends Controller {
	public function paletteStockCartView(&$route, &$data, &$code) {
		if (!$this->cart->hasProducts() && empty($this->session->data['vouchers'])) {
			return;
		}

		if (!$this->cartHasPaletteStock()) {
			$this->load->language('checkout/cart');
			$data['error_warning'] = $this->language->get('error_stock');
		}
	}

	public function paletteStockCheckoutGuard(&$route, &$data) {
		if ($this->cartHasPaletteStock()) {
			return;
		}

		$this->load->language('checkout/cart');
		$this->session->data['error'] = $this->language->get('error_stock');

		return $this->load->controller('checkout/cart');
	}

	public function paletteStockCartAddGuard(&$route, &$data) {
		if (($this->request->server['REQUEST_METHOD'] ?? '') !== 'POST') {
			return;
		}

		if (!isset($this->request->post['product_id'])) {
			return;
		}

		if (!is_file(DIR_APPLICATION . 'model/extension/module/cyberpunks_shop_option_fields.php')) {
			return;
		}

		$product_id = (int)$this->request->post['product_id'];
		$option = isset($this->request->post['option']) && is_array($this->request->post['option'])
			? array_filter($this->request->post['option'])
			: array();

		$this->load->model('extension/module/cyberpunks_shop_option_fields');
		$error = $this->model_extension_module_cyberpunks_shop_option_fields->validateSelectedOptionsPaletteStock($product_id, $option);

		if ($error === '') {
			return;
		}

		$json = array(
			'error' => array(
				'warning' => $error
			),
			'redirect' => str_replace('&amp;', '&', $this->url->link('product/product', 'product_id=' . $product_id))
		);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));

		return $this->response->getOutput();
	}

	private function cartHasPaletteStock() {
		if (!is_file(DIR_SYSTEM . 'library/cyberpunks_palette_stock.php')) {
			return true;
		}

		require_once(DIR_SYSTEM . 'library/cyberpunks_palette_stock.php');

		return CyberpunksPaletteStock::cartHasPaletteStock($this->db, $this->cart->getProducts());
	}
}
