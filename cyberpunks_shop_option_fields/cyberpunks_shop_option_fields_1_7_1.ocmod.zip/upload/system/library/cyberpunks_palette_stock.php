<?php
/**
 * Palette color in-stock checks (usable from Cart\Cart without Loader).
 */
class CyberpunksPaletteStock {
	public static function tablesExist($db) {
		$query = $db->query("SHOW TABLES LIKE '" . $db->escape(DB_PREFIX . "cyberpunks_option_value_palette_color") . "'");

		return (bool)$query->num_rows;
	}

	public static function paletteColorTableHasInStockColumn($db) {
		if (!self::tablesExist($db)) {
			return false;
		}

		$query = $db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "cyberpunks_color_palette_color` LIKE 'in_stock'");

		return (bool)$query->num_rows;
	}

	public static function paletteHasInStockColor($db, $palette_id) {
		$palette_id = (int)$palette_id;

		if ($palette_id <= 0 || !self::paletteColorTableHasInStockColumn($db)) {
			return true;
		}

		$query = $db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "cyberpunks_color_palette_color` WHERE palette_id = '" . $palette_id . "' AND in_stock = '1'");

		return !empty($query->row['total']);
	}

	public static function isOptionValueInStock($db, $option_value_id) {
		$option_value_id = (int)$option_value_id;

		if ($option_value_id <= 0 || !self::tablesExist($db) || !self::paletteColorTableHasInStockColumn($db)) {
			return true;
		}

		$query = $db->query("SELECT c.is_random, c.in_stock, c.palette_id
			FROM `" . DB_PREFIX . "cyberpunks_option_value_palette_color` l
			LEFT JOIN `" . DB_PREFIX . "cyberpunks_color_palette_color` c ON (l.color_id = c.color_id)
			LEFT JOIN `" . DB_PREFIX . "cyberpunks_color_palette` p ON (c.palette_id = p.palette_id)
			WHERE l.option_value_id = '" . $option_value_id . "'
			AND p.status = '1'
			LIMIT 1");

		if (!$query->num_rows) {
			return true;
		}

		if (!empty($query->row['is_random'])) {
			return self::paletteHasInStockColor($db, (int)$query->row['palette_id']);
		}

		return !empty($query->row['in_stock']);
	}

	public static function isProductOptionValueInStock($db, $product_option_value_id) {
		$product_option_value_id = (int)$product_option_value_id;

		if ($product_option_value_id <= 0) {
			return true;
		}

		$query = $db->query("SELECT option_value_id FROM `" . DB_PREFIX . "product_option_value` WHERE product_option_value_id = '" . $product_option_value_id . "' LIMIT 1");

		if (!$query->num_rows) {
			return true;
		}

		return self::isOptionValueInStock($db, (int)$query->row['option_value_id']);
	}

	public static function validateCartProductPaletteStock($db, array $cart_product) {
		if (empty($cart_product['option']) || !is_array($cart_product['option']) || !self::tablesExist($db)) {
			return '';
		}

		foreach ($cart_product['option'] as $option_row) {
			$product_option_value_id = isset($option_row['product_option_value_id']) ? (int)$option_row['product_option_value_id'] : 0;

			if ($product_option_value_id <= 0) {
				continue;
			}

			if (!self::isProductOptionValueInStock($db, $product_option_value_id)) {
				$color_name = self::getProductOptionValueLabel($db, $product_option_value_id, isset($option_row['value']) ? $option_row['value'] : '');

				return $color_name !== ''
					? sprintf('The selected color "%s" is currently out of stock.', $color_name)
					: 'One of the selected colors is currently out of stock.';
			}
		}

		return '';
	}

	public static function cartHasPaletteStock($db, array $cart_products) {
		foreach ($cart_products as $cart_product) {
			if (self::validateCartProductPaletteStock($db, $cart_product) !== '') {
				return false;
			}
		}

		return true;
	}

	private static function getProductOptionValueLabel($db, $product_option_value_id, $fallback = '') {
		$query = $db->query("SELECT ovd.name
			FROM `" . DB_PREFIX . "product_option_value` pov
			LEFT JOIN `" . DB_PREFIX . "option_value_description` ovd ON (pov.option_value_id = ovd.option_value_id)
			WHERE pov.product_option_value_id = '" . (int)$product_option_value_id . "'
			LIMIT 1");

		if ($query->num_rows && trim((string)$query->row['name']) !== '') {
			return trim((string)$query->row['name']);
		}

		return trim((string)$fallback);
	}
}
