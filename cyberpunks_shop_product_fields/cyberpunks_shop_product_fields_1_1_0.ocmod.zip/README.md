# Cyberpunks Shop Product Fields

Custom product fields on the **Custom** tab (Catalog → Products → Edit).

## Field types

| Type | UI |
|------|-----|
| Text | single-line input |
| Checkbox | yes/no |
| Select | dropdown (`value` or `value\|Label` per line) |
| Editor | Summernote WYSIWYG (HTML) |

## Theme usage

Values are available as `fields.<field_key>` on the product page.

```twig
{{ fields.amazon_link }}
{{ fields.page_content|raw }}
```

Example: create field key `page_content`, type **Editor**, then long product HTML renders below the buy box via `product.twig`.

## Install / update

```bash
./build-ocmod.sh cyberpunks_shop_product_fields
```

1. Extensions → Installer → upload zip (files under `upload/` overwrite previous module files)
2. Modifications → **Refresh**
3. Extensions → Modules → Cyberpunks Shop Product Fields → configure fields
