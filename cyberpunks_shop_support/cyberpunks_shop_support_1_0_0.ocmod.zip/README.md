# Cyberpunks Shop Support

Stores contact-form submissions as support tickets in OpenCart admin (Sales → Support requests).

## Features

- Ticket per form submit with request ID (same ID as email subject)
- Statuses: Open / In progress / Waiting for customer / Closed
- Full conversation thread in admin
- Reply from admin (saves + emails customer)
- Option to log a customer email reply manually (no outbound mail)
- Keeps existing notify email to store + auto-reply to customer

## Install

1. Upload `cyberpunks_shop_support_1_0_0.ocmod.zip` (Extensions → Installer).
2. Extensions → Modifications → Refresh.
3. Extensions → Modules → **Cyberpunks Support** → Install (creates DB tables + permissions).
4. Also keep/update **Information Additional Fields** ≥ 1.12.1 so the contact form creates tickets.

## Workflow

1. Customer submits Contact us form.
2. Ticket appears under **Sales → Support requests**.
3. Open ticket → change status → write reply → Save / Send.
4. If the customer replies by email, paste their message with **Log as customer message**.

## Note

Inbound email is not auto-imported. Customer replies to your mailbox; log them on the ticket when needed.
