<?php
$_['heading_title'] = 'Cyberpunks Shop Support';

$_['text_extension'] = 'Extensions';
$_['text_home'] = 'Home';
$_['text_list'] = 'Support request list';
$_['text_ticket'] = 'Request %s';
$_['text_no_results'] = 'No support requests yet.';
$_['text_confirm'] = 'Are you sure?';
$_['text_success_reply'] = 'Reply saved and emailed to the customer.';
$_['text_success_logged'] = 'Customer message logged on the ticket.';
$_['text_success_status'] = 'Status updated.';
$_['text_success_delete'] = 'Selected requests deleted.';
$_['text_pagination'] = 'Showing %d to %d of %d (%d Pages)';

$_['text_status_open'] = 'Open';
$_['text_status_in_progress'] = 'In progress';
$_['text_status_waiting'] = 'Waiting for customer';
$_['text_status_closed'] = 'Closed';

$_['text_author_customer'] = 'Customer';
$_['text_author_admin'] = 'Support';

$_['text_thread'] = 'Conversation';
$_['text_reply'] = 'Reply to customer';
$_['text_log_customer'] = 'Log as customer message (no email)';
$_['text_set_waiting'] = 'Set status to “Waiting for customer” after reply';

$_['column_request'] = 'Request';
$_['column_email'] = 'Email';
$_['column_reason'] = 'Reason';
$_['column_status'] = 'Status';
$_['column_messages'] = 'Msgs';
$_['column_preview'] = 'Preview';
$_['column_date_added'] = 'Created';
$_['column_date_modified'] = 'Updated';
$_['column_action'] = 'Action';

$_['entry_request_code'] = 'Request ID';
$_['entry_email'] = 'Email';
$_['entry_status'] = 'Status';
$_['entry_reply'] = 'Message';

$_['button_filter'] = 'Filter';
$_['button_view'] = 'View';
$_['button_delete'] = 'Delete';
$_['button_save'] = 'Save / Send';
$_['button_cancel'] = 'Back';

$_['email_subject_reply'] = 'Cyberpunks.shop - Support request - %s';
$_['email_text_reply_intro'] = "Reply from Cyberpunks Shop support (request %s):\n";
$_['email_text_reply_footer'] = "—\nYou can reply to this email. Please keep the request ID in the subject if possible.";

$_['error_permission'] = 'Warning: You do not have permission to modify support requests!';
$_['error_not_found'] = 'Support request not found.';
