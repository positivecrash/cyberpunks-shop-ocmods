# Cyberpunks Shop Support

Stores contact-form submissions as support tickets. Top-level admin left nav: **Cyberpunks Shop Support**.

## Features

- Ticket per form submit with request ID (same ID as email subject)
- Statuses: Open / In progress / Waiting for customer / Closed
- Stores visitor language / currency / country when available
- First-time email gets an automatic thank-you confirmation (via Information Additional Fields ≥ 1.12.2)
- Full conversation thread in admin
- Reply from admin (saves + emails customer)
- Option to log a customer email reply manually (no outbound mail)
- Module **Status** Enabled/Disabled
- Keeps existing notify email to store

## Install

1. Upload `cyberpunks_shop_support_1_0_4.ocmod.zip` (Extensions → Installer).
2. Extensions → Modifications → Refresh.
3. Extensions → Modules → **Cyberpunks Shop Support** → Install (or Edit → Save if already installed).
4. Set **Status** to Enabled and Save.
5. Also keep/update **Information Additional Fields** ≥ 1.12.2 so the contact form creates tickets + first-email confirmation.
6. Hard-refresh admin — left nav shows **Cyberpunks Shop Support** between Sales and Customers.

## Upgrade from 1.0.x

1. Upload the new zip → Modifications → Refresh.
2. Open any support ticket once (runs schema migrate for language/currency/country columns).
3. Upload Information Additional Fields 1.12.2 → Refresh.

## Workflow

1. Customer submits Contact us form.
2. Open **Cyberpunks Shop Support** in the left menu.
3. Open ticket → change status → write reply → Save / Send.
4. If the customer replies by email, paste their message with **Log as customer message**.

## Note

Inbound email is not auto-imported. Customer replies to your mailbox; log them on the ticket when needed.
