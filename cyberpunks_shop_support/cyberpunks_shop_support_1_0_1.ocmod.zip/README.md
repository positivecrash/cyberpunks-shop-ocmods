# Cyberpunks Shop Support

Stores contact-form submissions as support tickets. Top-level admin menu: **Support**.

## Features

- Ticket per form submit with request ID (same ID as email subject)
- Statuses: Open / In progress / Waiting for customer / Closed
- Full conversation thread in admin
- Reply from admin (saves + emails customer)
- Option to log a customer email reply manually (no outbound mail)
- Keeps existing notify email to store + auto-reply to customer

## Install

1. Upload `cyberpunks_shop_support_1_0_1.ocmod.zip` (Extensions → Installer).
2. Extensions → Modifications → Refresh.
3. Extensions → Modules → **Cyberpunks Support** → Install (creates DB tables + permissions).
4. Also keep/update **Information Additional Fields** ≥ 1.12.1 so the contact form creates tickets.

Left menu: top-level **Support** (life-ring icon), between Sales and Customers.

## Workflow

1. Customer submits Contact us form.
2. Open **Support** in the left menu.
3. Open ticket → change status → write reply → Save / Send.
4. If the customer replies by email, paste their message with **Log as customer message**.

## Note

Inbound email is not auto-imported. Customer replies to your mailbox; log them on the ticket when needed.
