<?php
class ControllerSaleCyberpunksShopSupport extends Controller {
	private $error = array();

	public function index() {
		$data = $this->load->language('sale/cyberpunks_shop_support');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('sale/cyberpunks_shop_support');
		$this->model_sale_cyberpunks_shop_support->ensureSchema();
		$this->getList($data);
	}

	public function info() {
		$data = $this->load->language('sale/cyberpunks_shop_support');
		$this->load->model('sale/cyberpunks_shop_support');
		$this->model_sale_cyberpunks_shop_support->ensureSchema();

		$ticket_id = isset($this->request->get['ticket_id']) ? (int)$this->request->get['ticket_id'] : 0;
		$ticket = $this->model_sale_cyberpunks_shop_support->getTicket($ticket_id);

		if (!$ticket) {
			$this->session->data['error_warning'] = $this->language->get('error_not_found');
			$this->response->redirect($this->url->link('sale/cyberpunks_shop_support', 'user_token=' . $this->session->data['user_token'], true));
			return;
		}

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateModify()) {
			if (!empty($this->request->post['status'])) {
				$this->model_sale_cyberpunks_shop_support->updateStatus($ticket_id, $this->request->post['status']);
			}

			$reply = isset($this->request->post['reply']) ? trim((string)$this->request->post['reply']) : '';
			$log_customer = !empty($this->request->post['log_customer_reply']);

			if ($reply !== '') {
				if ($log_customer) {
					$this->model_sale_cyberpunks_shop_support->addCustomerMessage($ticket_id, $reply);
					$this->session->data['success'] = $this->language->get('text_success_logged');
				} else {
					$this->model_sale_cyberpunks_shop_support->addAdminMessage($ticket_id, $reply, (int)$this->user->getId());
					$this->sendReplyEmail($ticket, $reply);
					if (!empty($this->request->post['status_after_reply']) && $this->request->post['status_after_reply'] === 'waiting') {
						$this->model_sale_cyberpunks_shop_support->updateStatus($ticket_id, 'waiting');
					}
					$this->session->data['success'] = $this->language->get('text_success_reply');
				}
			} else {
				$this->session->data['success'] = $this->language->get('text_success_status');
			}

			$this->response->redirect($this->url->link('sale/cyberpunks_shop_support/info', 'user_token=' . $this->session->data['user_token'] . '&ticket_id=' . $ticket_id, true));
			return;
		}

		$this->document->setTitle($this->language->get('heading_title') . ' #' . $ticket['request_code']);

		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('sale/cyberpunks_shop_support', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $ticket['request_code'],
			'href' => $this->url->link('sale/cyberpunks_shop_support/info', 'user_token=' . $this->session->data['user_token'] . '&ticket_id=' . $ticket_id, true)
		);

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} elseif (!empty($this->session->data['error_warning'])) {
			$data['error_warning'] = $this->session->data['error_warning'];
			unset($this->session->data['error_warning']);
		} else {
			$data['error_warning'] = '';
		}

		if (!empty($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_ticket'] = sprintf($this->language->get('text_ticket'), $ticket['request_code']);
		$data['ticket'] = $ticket;
		$data['statuses'] = $this->model_sale_cyberpunks_shop_support->getStatuses();
		$data['status_labels'] = array();
		foreach ($data['statuses'] as $status) {
			$data['status_labels'][$status] = $this->language->get('text_status_' . $status);
		}

		$messages = $this->model_sale_cyberpunks_shop_support->getMessages($ticket_id);
		$data['messages'] = array();
		foreach ($messages as $message) {
			$data['messages'][] = array(
				'author' => $message['author'],
				'author_label' => $message['author'] === 'admin' ? $this->language->get('text_author_admin') : $this->language->get('text_author_customer'),
				'message' => nl2br(htmlspecialchars($message['message'], ENT_QUOTES, 'UTF-8')),
				'date_added' => $message['date_added']
			);
		}

		$data['action'] = $this->url->link('sale/cyberpunks_shop_support/info', 'user_token=' . $this->session->data['user_token'] . '&ticket_id=' . $ticket_id, true);
		$data['cancel'] = $this->url->link('sale/cyberpunks_shop_support', 'user_token=' . $this->session->data['user_token'], true);
		$data['user_token'] = $this->session->data['user_token'];

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('sale/cyberpunks_shop_support_info', $data));
	}

	public function delete() {
		$this->load->language('sale/cyberpunks_shop_support');
		$this->load->model('sale/cyberpunks_shop_support');

		if (isset($this->request->post['selected']) && $this->validateModify()) {
			foreach ((array)$this->request->post['selected'] as $ticket_id) {
				$this->model_sale_cyberpunks_shop_support->deleteTicket((int)$ticket_id);
			}
			$this->session->data['success'] = $this->language->get('text_success_delete');
		}

		$this->response->redirect($this->url->link('sale/cyberpunks_shop_support', 'user_token=' . $this->session->data['user_token'], true));
	}

	protected function getList($data = array()) {
		if (!$data) {
			$data = $this->load->language('sale/cyberpunks_shop_support');
		}
		$filter_request_code = isset($this->request->get['filter_request_code']) ? $this->request->get['filter_request_code'] : '';
		$filter_email = isset($this->request->get['filter_email']) ? $this->request->get['filter_email'] : '';
		$filter_status = isset($this->request->get['filter_status']) ? $this->request->get['filter_status'] : '';
		$sort = isset($this->request->get['sort']) ? $this->request->get['sort'] : 't.date_modified';
		$order = isset($this->request->get['order']) ? $this->request->get['order'] : 'DESC';
		$page = isset($this->request->get['page']) ? (int)$this->request->get['page'] : 1;

		$url = '';
		if ($filter_request_code !== '') {
			$url .= '&filter_request_code=' . urlencode(html_entity_decode($filter_request_code, ENT_QUOTES, 'UTF-8'));
		}
		if ($filter_email !== '') {
			$url .= '&filter_email=' . urlencode(html_entity_decode($filter_email, ENT_QUOTES, 'UTF-8'));
		}
		if ($filter_status !== '') {
			$url .= '&filter_status=' . urlencode($filter_status);
		}
		$url .= '&sort=' . $sort . '&order=' . $order;
		if ($page > 1) {
			$url .= '&page=' . $page;
		}

		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('sale/cyberpunks_shop_support', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['delete'] = $this->url->link('sale/cyberpunks_shop_support/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$filter_data = array(
			'filter_request_code' => $filter_request_code,
			'filter_email' => $filter_email,
			'filter_status' => $filter_status,
			'sort' => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$ticket_total = $this->model_sale_cyberpunks_shop_support->getTotalTickets($filter_data);
		$results = $this->model_sale_cyberpunks_shop_support->getTickets($filter_data);

		$data['tickets'] = array();
		foreach ($results as $result) {
			$preview = isset($result['first_message']) ? $result['first_message'] : '';
			if (utf8_strlen($preview) > 80) {
				$preview = utf8_substr($preview, 0, 80) . '…';
			}
			$data['tickets'][] = array(
				'ticket_id' => $result['ticket_id'],
				'request_code' => $result['request_code'],
				'email' => $result['email'],
				'reason' => $result['reason'],
				'status' => $result['status'],
				'status_label' => $this->language->get('text_status_' . $result['status']),
				'message_count' => (int)$result['message_count'],
				'preview' => $preview,
				'date_added' => $result['date_added'],
				'date_modified' => $result['date_modified'],
				'view' => $this->url->link('sale/cyberpunks_shop_support/info', 'user_token=' . $this->session->data['user_token'] . '&ticket_id=' . $result['ticket_id'] . $url, true)
			);
		}

		$data['heading_title'] = $this->language->get('heading_title');
		$data['user_token'] = $this->session->data['user_token'];
		$data['statuses'] = $this->model_sale_cyberpunks_shop_support->getStatuses();
		$data['status_labels'] = array();
		foreach ($data['statuses'] as $status) {
			$data['status_labels'][$status] = $this->language->get('text_status_' . $status);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} elseif (!empty($this->session->data['error_warning'])) {
			$data['error_warning'] = $this->session->data['error_warning'];
			unset($this->session->data['error_warning']);
		} else {
			$data['error_warning'] = '';
		}

		if (!empty($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['filter_request_code'] = $filter_request_code;
		$data['filter_email'] = $filter_email;
		$data['filter_status'] = $filter_status;
		$data['sort'] = $sort;
		$data['order'] = $order;

		$pagination = new Pagination();
		$pagination->total = $ticket_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('sale/cyberpunks_shop_support', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);
		$data['pagination'] = $pagination->render();
		$data['results'] = sprintf($this->language->get('text_pagination'), ($ticket_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($ticket_total - $this->config->get('config_limit_admin'))) ? $ticket_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $ticket_total, ceil($ticket_total / $this->config->get('config_limit_admin')));

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('sale/cyberpunks_shop_support_list', $data));
	}

	private function sendReplyEmail($ticket, $reply_text) {
		$mail = new Mail($this->config->get('config_mail_engine'));
		$mail->parameter = $this->config->get('config_mail_parameter');
		$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
		$mail->smtp_username = $this->config->get('config_mail_smtp_username');
		$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
		$mail->smtp_port = $this->config->get('config_mail_smtp_port');
		$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

		$mail->setTo($ticket['email']);
		$mail->setFrom($this->config->get('config_email'));
		$mail->setSender(html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
		$mail->setReplyTo($this->config->get('config_email'));
		$mail->setSubject(html_entity_decode(sprintf($this->language->get('email_subject_reply'), $ticket['request_code']), ENT_QUOTES, 'UTF-8'));
		$mail->setText(
			sprintf($this->language->get('email_text_reply_intro'), $ticket['request_code']) . "\n\n"
			. $reply_text . "\n\n"
			. $this->language->get('email_text_reply_footer')
		);
		$mail->send();
	}

	protected function validateModify() {
		if (!$this->user->hasPermission('modify', 'sale/cyberpunks_shop_support')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		return !$this->error;
	}
}
