<?php
class ControllerExtensionModuleCyberpunksShopSupport extends Controller {
	public function install() {
		$this->load->model('sale/cyberpunks_shop_support');
		$this->model_sale_cyberpunks_shop_support->ensureSchema();

		$this->load->model('user/user_group');
		foreach ($this->db->query("SELECT user_group_id FROM `" . DB_PREFIX . "user_group`")->rows as $user_group) {
			$this->model_user_user_group->addPermission($user_group['user_group_id'], 'access', 'sale/cyberpunks_shop_support');
			$this->model_user_user_group->addPermission($user_group['user_group_id'], 'modify', 'sale/cyberpunks_shop_support');
			$this->model_user_user_group->addPermission($user_group['user_group_id'], 'access', 'extension/module/cyberpunks_shop_support');
			$this->model_user_user_group->addPermission($user_group['user_group_id'], 'modify', 'extension/module/cyberpunks_shop_support');
		}
	}

	public function uninstall() {
		// Keep ticket data on uninstall.
	}

	public function index() {
		$this->load->language('extension/module/cyberpunks_shop_support');
		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('sale/cyberpunks_shop_support');
		$this->model_sale_cyberpunks_shop_support->ensureSchema();

		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_success'] = '';
		$data['entry_status'] = $this->language->get('entry_status');
		$data['help'] = $this->language->get('text_help');
		$data['button_tickets'] = $this->language->get('button_tickets');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['tickets'] = $this->url->link('sale/cyberpunks_shop_support', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/cyberpunks_shop_support', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/cyberpunks_shop_support', $data));
	}
}
