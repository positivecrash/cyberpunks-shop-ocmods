<?php
$_['heading_title'] = 'Cyberpunks Support';
$_['text_extension'] = 'Extensions';
$_['text_home'] = 'Home';
$_['text_edit'] = 'Support tickets module';
$_['text_help'] = 'Contact form submissions are stored as support tickets. Open Sales → Support requests to view threads and reply.';
$_['entry_status'] = 'Status';
$_['button_tickets'] = 'Open support requests';
$_['button_cancel'] = 'Cancel';
