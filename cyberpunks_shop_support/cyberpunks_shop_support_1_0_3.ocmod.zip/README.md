# Cyberpunks Shop Support

Stores contact-form submissions as support tickets. Top-level admin left nav: **Cyberpunks Shop Support**.

## Features

- Ticket per form submit with request ID (same ID as email subject)
- Statuses: Open / In progress / Waiting for customer / Closed
- Full conversation thread in admin
- Reply from admin (saves + emails customer)
- Option to log a customer email reply manually (no outbound mail)
- Module **Status** Enabled/Disabled
- Keeps existing notify email to store + auto-reply to customer

## Install

1. Upload `cyberpunks_shop_support_1_0_3.ocmod.zip` (Extensions → Installer).
2. Extensions → Modifications → Refresh (registers the package; menu itself uses an event).
3. Extensions → Modules → **Cyberpunks Shop Support** → Install (or Edit → Save if already installed).
4. Set **Status** to Enabled and Save.
5. Also keep/update **Information Additional Fields** ≥ 1.12.1 so the contact form creates tickets.
6. Hard-refresh admin (or re-login) — left nav shows **Cyberpunks Shop Support** between Sales and Customers.

## Upgrade from 1.0.x

1. Upload the new zip → Modifications → Refresh.
2. Open the module Edit page once (registers the menu event + status setting) → Save with Enabled.
3. Use the life-ring item in NAVIGATION (or blue button on settings) for the ticket list.

## Workflow

1. Customer submits Contact us form.
2. Open **Cyberpunks Shop Support** in the left menu.
3. Open ticket → change status → write reply → Save / Send.
4. If the customer replies by email, paste their message with **Log as customer message**.

## Note

Inbound email is not auto-imported. Customer replies to your mailbox; log them on the ticket when needed.
