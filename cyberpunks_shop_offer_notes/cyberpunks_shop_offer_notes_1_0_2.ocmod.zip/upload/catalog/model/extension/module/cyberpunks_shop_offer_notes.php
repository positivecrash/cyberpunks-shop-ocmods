<?php
/**
 * Note column on product_special + product_discount; active special note for PDP.
 */
class ModelExtensionModuleCyberpunksShopOfferNotes extends Model {
	public function ensureSchema() {
		$this->ensureNoteColumn('product_special');
		$this->ensureNoteColumn('product_discount');
	}

	private function ensureNoteColumn($table) {
		$full = DB_PREFIX . $table;
		$exists = $this->db->query("SHOW TABLES LIKE '" . $this->db->escape($full) . "'");

		if (!$exists->num_rows) {
			return false;
		}

		$col = $this->db->query("SHOW COLUMNS FROM `" . $full . "` LIKE 'note'");

		if ($col->num_rows) {
			return true;
		}

		$this->db->query("ALTER TABLE `" . $full . "` ADD `note` VARCHAR(255) NOT NULL DEFAULT '' AFTER `date_end`");

		return true;
	}

	/**
	 * Note from the same special row that drives the active sale price.
	 */
	public function getActiveSpecialNote($product_id) {
		$this->ensureSchema();

		$product_id = (int)$product_id;

		if ($product_id < 1) {
			return '';
		}

		$customer_group_id = (int)$this->config->get('config_customer_group_id');

		$query = $this->db->query(
			"SELECT `note` FROM `" . DB_PREFIX . "product_special`"
			. " WHERE `product_id` = '" . $product_id . "'"
			. " AND `customer_group_id` = '" . $customer_group_id . "'"
			. " AND ((`date_start` = '0000-00-00' OR `date_start` < NOW())"
			. " AND (`date_end` = '0000-00-00' OR `date_end` > NOW()))"
			. " ORDER BY `priority` ASC, `price` ASC LIMIT 1"
		);

		if (!$query->num_rows) {
			return '';
		}

		return trim((string)$query->row['note']);
	}
}
