<?php
class ModelExtensionModuleCyberpunksShopOfferNotes extends Model {
	public function ensureSchema() {
		$this->ensureNoteColumn('product_special');
		$this->ensureNoteColumn('product_discount');
	}

	private function ensureNoteColumn($table) {
		$full = DB_PREFIX . $table;
		$exists = $this->db->query("SHOW TABLES LIKE '" . $this->db->escape($full) . "'");

		if (!$exists->num_rows) {
			return false;
		}

		$col = $this->db->query("SHOW COLUMNS FROM `" . $full . "` LIKE 'note'");

		if ($col->num_rows) {
			return true;
		}

		$this->db->query("ALTER TABLE `" . $full . "` ADD `note` VARCHAR(255) NOT NULL DEFAULT '' AFTER `date_end`");

		return true;
	}
}
