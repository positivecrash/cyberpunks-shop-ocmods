# Cyberpunks Shop Offer Notes

Adds a **Note** field on each row of product **Special** and **Discount** tabs. Notes are stored on `product_special.note` / `product_discount.note` and shown on the product page.

## Install

```bash
./build-ocmod.sh cyberpunks_shop_offer_notes
```

1. Extensions → Installer → upload zip  
2. Modifications → **Refresh**  
3. Catalog → Product → **Special** / **Discount** → fill **Note** → Save  

Schema columns are created automatically on first admin product load.

## Theme

`github-templates/template/product/partials/price.twig`:

- `special_note` — note from the active Special  
- `discounts[].note` — per quantity-discount row  

Deploy the theme after installing the OCMOD.

## Changelog

### 1.0.2
- Fix Note column header (OpenCart OCMOD only matches single-line searches)

### 1.0.1
- Fix admin Special/Discount Note column (OCMOD searches were too large and skipped)

### 1.0.0
- Note column on Special and Discount admin rows  
- Catalog: `special_note` + `note` on each `discounts[]` item  
