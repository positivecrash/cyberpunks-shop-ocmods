<?php

$OPENCART_DB_HOST = getenv('OPENCART_DB_HOST');
$OPENCART_DB_USER =  getenv('OPENCART_DB_USER');
$OPENCART_DB_PASSWORD = getenv('OPENCART_DB_PASSWORD');
$OPENCART_DB_NAME = getenv('OPENCART_DB_NAME');
$OPENCART_DB_PREFIX = getenv('OPENCART_DB_PREFIX');

// Create connection
$connection = new mysqli($OPENCART_DB_HOST, $OPENCART_DB_USER, $OPENCART_DB_PASSWORD, $OPENCART_DB_NAME);
// Check connection
if ($connection->connect_error) {
    throw new Exception("Connection failed: " . $connection->connect_error);
}
// Add plugin tables
$connection->query("CREATE TABLE IF NOT EXISTS `" . $OPENCART_DB_PREFIX . "revolut_order` (
          `revolut_order_id` int(11) NOT NULL AUTO_INCREMENT,
          `order_id` int(11) NOT NULL,
          `revolut_id` varchar(255) NOT NULL,
          `revolut_public_id` varchar(255) NOT NULL,
          `currency_code` CHAR(3) NOT NULL,
          `total` DECIMAL (10,2) NOT NULL,
          `date_added` DATETIME NOT NULL,
          `date_modified` DATETIME NOT NULL,
          PRIMARY KEY (`revolut_order_id`)
        ) ENGINE=MyISAM DEFAULT COLLATE=utf8_general_ci;");

$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "extension` (`extension_id`, `type`, `code`) VALUES (NULL, 'payment', 'revolut');");

//Add permissions
$result = $connection->query("SELECT permission  FROM `" . $OPENCART_DB_PREFIX . "user_group` WHERE `name` LIKE 'Administrator';");
$row = $result->fetch_assoc();
$permissions = json_decode($row['permission'], true);
$permissions['access'][] = "extension/payment/revolut";
$permissions['access'][] = "extension/payment/revolut_pay";
$permissions['modify'][] = "extension/payment/revolut";
$permissions['modify'][] = "extension/payment/revolut_pay";
$connection->query("UPDATE `" . $OPENCART_DB_PREFIX . "user_group` SET permission = '" . json_encode($permissions) . "' WHERE `name` LIKE 'Administrator';");

//add plugin settings
$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_api_key', 'sk_wi4RcsU1uKXuBg6IyBMu4qrwQhQmUz7_7UwosyyVE0B6LluF_bu1foK__KX4LOHj');");
$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_payment_title', 'Pay By Revolut');");
$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_total', '0');");
$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_geo_zone_id', '0');");
$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_test', '1');");
$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_sort_order', '1');");
$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_capture_mode', 'AUTOMATIC');");


$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_refunded_status_id', '11');");
$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_failed_status_id', '10');");
$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_pending_status_id', '1');");
$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_processing_status_id', '2');");
$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_authorised_status_id', '2');");
$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_completed_status_id', '5');");
$connection->query("INSERT INTO `" . $OPENCART_DB_PREFIX . "setting` (`serialized`, `code`, `key`, `value`) VALUES ('0', 'payment_revolut', 'payment_revolut_status', '1');");

//close DB connection
$connection->close();
