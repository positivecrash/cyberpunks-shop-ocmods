<?php
/**
 * After Revolut Pay succeeds, copy customer + shipping from Merchant API (and Fast-checkout cache)
 * onto the OpenCart draft order — before status/mail finalize.
 */
class CyberpunksRevolutOrderSync {
	/**
	 * @param object $registry OpenCart registry
	 * @param int    $oc_order_id
	 * @param string $revolut_order_id Merchant order UUID
	 * @param array  $revolut_order    Optional pre-fetched order payload
	 * @return array{applied:bool,source:string,detail:string}
	 */
	public static function applyToOpenCartOrder($registry, $oc_order_id, $revolut_order_id, $revolut_order = null) {
		$oc_order_id = (int)$oc_order_id;
		$revolut_order_id = trim((string)$revolut_order_id);
		$log = $registry->get('log');
		$db = $registry->get('db');
		$config = $registry->get('config');
		$cache = $registry->get('cache');

		$result = array('applied' => false, 'source' => 'none', 'detail' => '');

		if ($oc_order_id <= 0 || $revolut_order_id === '') {
			$result['detail'] = 'missing_ids';
			return $result;
		}

		if ($revolut_order === null || !is_array($revolut_order) || empty($revolut_order['id'])) {
			$revolut_order = self::fetchOrderWithRetry($registry, $revolut_order_id, 5);
		}

		$customer = (isset($revolut_order['customer']) && is_array($revolut_order['customer'])) ? $revolut_order['customer'] : array();
		$ship = self::extractShippingAddress($revolut_order);

		// Fast-checkout webhook cache (address chosen after createOrder).
		if ((!self::isUsableStreet($ship) || self::isPlaceholderStreet($ship)) && $cache) {
			$cached = self::loadCachedAddress($cache, $registry, $revolut_order_id, $revolut_order);
			if ($cached && self::isUsableStreet($cached) && !self::isPlaceholderStreet($cached)) {
				$ship = $cached;
				$result['source'] = 'fast_checkout_cache';
			}
		} elseif (self::isUsableStreet($ship) && !self::isPlaceholderStreet($ship)) {
			$result['source'] = 'merchant_api';
		}

		$email = self::clean(isset($customer['email']) ? $customer['email'] : '');
		$name = self::clean(isset($customer['full_name']) ? $customer['full_name'] : '');
		if ($name === '' && (!empty($customer['first_name']) || !empty($customer['last_name']))) {
			$name = trim(
				self::clean(isset($customer['first_name']) ? $customer['first_name'] : '') . ' ' .
				self::clean(isset($customer['last_name']) ? $customer['last_name'] : '')
			);
		}
		$phone = self::clean(isset($customer['phone']) ? $customer['phone'] : '');

		$registry->get('load')->model('checkout/order');
		$existing = $registry->get('model_checkout_order')->getOrder($oc_order_id);
		if (!$existing) {
			$result['detail'] = 'oc_order_missing';
			return $result;
		}

		// Keep form/express email if Revolut has none.
		if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$email = self::clean(isset($existing['email']) ? $existing['email'] : '');
		}
		if ($email === 'express@cyberpunks.shop') {
			$email = '';
		}

		list($firstname, $lastname) = self::splitName($name);
		if ($firstname === '' || strcasecmp($firstname, 'Guest') === 0 || strcasecmp($firstname, 'Customer') === 0) {
			$ef = self::clean(isset($existing['firstname']) ? $existing['firstname'] : '');
			if ($ef !== '' && strcasecmp($ef, 'Guest') !== 0 && strcasecmp($ef, 'Customer') !== 0) {
				$firstname = $ef;
			}
		}
		if ($lastname === '' || strcasecmp($lastname, 'Customer') === 0) {
			$el = self::clean(isset($existing['lastname']) ? $existing['lastname'] : '');
			if ($el !== '' && strcasecmp($el, 'Customer') !== 0) {
				$lastname = $el;
			}
		}
		if ($firstname === '') {
			$firstname = 'Customer';
		}
		if ($phone === '' || $phone === '0000000') {
			$phone = self::clean(isset($existing['telephone']) ? $existing['telephone'] : '');
			if ($phone === '0000000') {
				$phone = '';
			}
		}

		$street_1 = '';
		$street_2 = '';
		$city = '';
		$postcode = '';
		$region = '';
		$country_name = isset($existing['shipping_country']) ? (string)$existing['shipping_country'] : '';
		$country_id = isset($existing['shipping_country_id']) ? (int)$existing['shipping_country_id'] : 0;
		$zone_id = isset($existing['shipping_zone_id']) ? (int)$existing['shipping_zone_id'] : 0;
		$zone_name = isset($existing['shipping_zone']) ? (string)$existing['shipping_zone'] : '';
		$address_format = isset($existing['shipping_address_format']) ? (string)$existing['shipping_address_format'] : '';

		$has_real_address = self::isUsableStreet($ship) && !self::isPlaceholderStreet($ship);

		if ($has_real_address) {
			$street_1 = self::streetLine($ship, 0);
			$street_2 = self::streetLine($ship, 1);
			$city = self::pick($ship, array('city', 'locality'));
			$postcode = self::pick($ship, array('postcode', 'postalCode', 'zip'));
			if ($postcode === '00000') {
				$postcode = '';
			}
			$region = self::pick($ship, array('region', 'administrativeArea', 'state'));
			$country_code = self::pick($ship, array('country_code', 'countryCode', 'country'));

			$country_info = self::countryByIso($db, $country_code);
			if ($country_info) {
				$country_id = (int)$country_info['country_id'];
				$country_name = $country_info['name'];
				$address_format = $country_info['address_format'];
				$zone = self::resolveZone($db, $country_id, $region);
				$zone_id = (int)$zone['zone_id'];
				$zone_name = $zone['name'] !== '' ? $zone['name'] : $region;
			}
		} else {
			// Do not keep quote placeholders on the order.
			$ex1 = self::clean(isset($existing['shipping_address_1']) ? $existing['shipping_address_1'] : '');
			$exc = self::clean(isset($existing['shipping_city']) ? $existing['shipping_city'] : '');
			$exp = self::clean(isset($existing['shipping_postcode']) ? $existing['shipping_postcode'] : '');
			if ($ex1 !== '' && strcasecmp($ex1, 'Express checkout') !== 0) {
				$street_1 = $ex1;
			}
			if ($exc !== '' && strcasecmp($exc, 'City') !== 0) {
				$city = $exc;
			}
			if ($exp !== '' && $exp !== '00000') {
				$postcode = $exp;
			}
			$street_2 = self::clean(isset($existing['shipping_address_2']) ? $existing['shipping_address_2'] : '');
		}

		$set = array(
			"firstname = '" . $db->escape($firstname) . "'",
			"lastname = '" . $db->escape($lastname) . "'",
			"telephone = '" . $db->escape($phone) . "'",
			"payment_firstname = '" . $db->escape($firstname) . "'",
			"payment_lastname = '" . $db->escape($lastname) . "'",
			"shipping_firstname = '" . $db->escape($firstname) . "'",
			"shipping_lastname = '" . $db->escape($lastname) . "'",
			"date_modified = NOW()",
		);

		if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$set[] = "email = '" . $db->escape($email) . "'";
		}

		if ($street_1 !== '' && $city !== '') {
			$set[] = "payment_address_1 = '" . $db->escape($street_1) . "'";
			$set[] = "payment_address_2 = '" . $db->escape($street_2) . "'";
			$set[] = "payment_city = '" . $db->escape($city) . "'";
			$set[] = "payment_postcode = '" . $db->escape($postcode) . "'";
			$set[] = "payment_country = '" . $db->escape($country_name) . "'";
			$set[] = "payment_country_id = '" . (int)$country_id . "'";
			$set[] = "payment_zone = '" . $db->escape($zone_name) . "'";
			$set[] = "payment_zone_id = '" . (int)$zone_id . "'";
			$set[] = "payment_address_format = '" . $db->escape($address_format) . "'";
			$set[] = "shipping_address_1 = '" . $db->escape($street_1) . "'";
			$set[] = "shipping_address_2 = '" . $db->escape($street_2) . "'";
			$set[] = "shipping_city = '" . $db->escape($city) . "'";
			$set[] = "shipping_postcode = '" . $db->escape($postcode) . "'";
			$set[] = "shipping_country = '" . $db->escape($country_name) . "'";
			$set[] = "shipping_country_id = '" . (int)$country_id . "'";
			$set[] = "shipping_zone = '" . $db->escape($zone_name) . "'";
			$set[] = "shipping_zone_id = '" . (int)$zone_id . "'";
			$set[] = "shipping_address_format = '" . $db->escape($address_format) . "'";
			$result['applied'] = true;
			if ($result['source'] === 'none') {
				$result['source'] = 'oc_existing_or_partial';
			}
		} elseif ($name !== '' || ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL))) {
			// At least contact from Revolut.
			$result['applied'] = true;
			if ($result['source'] === 'none') {
				$result['source'] = 'merchant_api_contact';
			}
		}

		$db->query("UPDATE `" . DB_PREFIX . "order` SET " . implode(', ', $set) . " WHERE order_id = '" . (int)$oc_order_id . "'");

		$result['detail'] = 'street=' . ($street_1 !== '' ? 'yes' : 'no') . ';city=' . ($city !== '' ? 'yes' : 'no') . ';name=' . ($name !== '' ? 'yes' : 'no');

		if ($log) {
			$log->write('CyberpunksRevolutOrderSync OC#' . $oc_order_id . ' rev=' . $revolut_order_id . ' source=' . $result['source'] . ' ' . $result['detail']);
		}

		return $result;
	}

	private static function fetchOrderWithRetry($registry, $revolut_order_id, $attempts) {
		$api_file = DIR_SYSTEM . 'library/vendor/revolut/api_request.php';
		if (!is_file($api_file)) {
			return array();
		}
		require_once($api_file);
		$config = $registry->get('config');
		$api = new ApiRequest($config->get('payment_revolut_api_key'), $config->get('payment_revolut_test'));

		$order = array();
		for ($i = 0; $i < $attempts; $i++) {
			$res = $api->get('orders/' . $revolut_order_id, true);
			$order = (!empty($res['response']) && is_array($res['response'])) ? $res['response'] : array();
			$ship = self::extractShippingAddress($order);
			$customer = (isset($order['customer']) && is_array($order['customer'])) ? $order['customer'] : array();
			$has_ship = self::isUsableStreet($ship) && !self::isPlaceholderStreet($ship);
			$has_name = self::clean(isset($customer['full_name']) ? $customer['full_name'] : '') !== '';
			if ($has_ship || ($i === $attempts - 1)) {
				break;
			}
			// Address/name sometimes appear a moment after completed webhook.
			usleep(400000);
		}

		return $order;
	}

	private static function extractShippingAddress(array $revolut_order) {
		if (isset($revolut_order['shipping_address']) && is_array($revolut_order['shipping_address'])) {
			return $revolut_order['shipping_address'];
		}
		if (isset($revolut_order['shipping']['address']) && is_array($revolut_order['shipping']['address'])) {
			return $revolut_order['shipping']['address'];
		}
		if (isset($revolut_order['shipping']) && is_array($revolut_order['shipping']) && isset($revolut_order['shipping']['street_line_1'])) {
			return $revolut_order['shipping'];
		}
		if (isset($revolut_order['deliver_to']) && is_array($revolut_order['deliver_to'])) {
			return $revolut_order['deliver_to'];
		}
		return array();
	}

	private static function loadCachedAddress($cache, $registry, $revolut_order_id, array $revolut_order) {
		$keys = array('cp_express_addr_order_' . $revolut_order_id);
		if (!empty($revolut_order['token'])) {
			$keys[] = 'cp_express_addr_order_' . $revolut_order['token'];
		}
		$session = $registry->get('session');
		if ($session && !empty($session->data['cp_express_token'])) {
			$keys[] = 'cp_express_addr_' . $session->data['cp_express_token'];
		}
		if ($session && !empty($session->data['cp_express_public_id'])) {
			$keys[] = 'cp_express_addr_order_' . $session->data['cp_express_public_id'];
		}

		foreach (array_unique($keys) as $key) {
			$cached = $cache->get($key);
			if (is_array($cached) && !empty($cached['address']) && is_array($cached['address'])) {
				return $cached['address'];
			}
		}

		// Durable webhook dump (written by express_validate_address).
		$refs = array($revolut_order_id);
		if (!empty($revolut_order['token'])) {
			$refs[] = $revolut_order['token'];
		}
		foreach ($refs as $ref) {
			$safe = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$ref);
			if ($safe === '' || !defined('DIR_CACHE')) {
				continue;
			}
			$path = DIR_CACHE . 'cp_revolut_ship_' . $safe . '.json';
			if (!is_file($path)) {
				continue;
			}
			$decoded = json_decode((string)file_get_contents($path), true);
			if (is_array($decoded) && $decoded) {
				return $decoded;
			}
		}

		return null;
	}

	private static function isUsableStreet($address) {
		if (!is_array($address) || !$address) {
			return false;
		}
		$street = self::streetLine($address, 0);
		$city = self::pick($address, array('city', 'locality'));
		return $street !== '' && $city !== '';
	}

	private static function isPlaceholderStreet($address) {
		if (!is_array($address)) {
			return true;
		}
		$street = self::streetLine($address, 0);
		$city = self::pick($address, array('city', 'locality'));
		$postcode = self::pick($address, array('postcode', 'postalCode', 'zip'));
		if (strcasecmp($street, 'Express checkout') === 0) {
			return true;
		}
		if (strcasecmp($city, 'City') === 0) {
			return true;
		}
		if ($postcode === '00000' && (strcasecmp($street, 'Express checkout') === 0 || $street === '')) {
			return true;
		}
		return false;
	}

	private static function streetLine($address, $index) {
		$keys = $index === 0
			? array('street_line_1', 'streetLine1', 'line_1', 'address_line_1', 'street')
			: array('street_line_2', 'streetLine2', 'line_2', 'address_line_2');
		return self::pick($address, $keys);
	}

	private static function pick($address, $keys) {
		foreach ($keys as $key) {
			if (!isset($address[$key])) {
				continue;
			}
			$val = self::clean($address[$key]);
			if ($val !== '') {
				return $val;
			}
		}
		return '';
	}

	private static function clean($value) {
		$value = trim((string)$value);
		if ($value === '' || strcasecmp($value, 'undefined') === 0 || strcasecmp($value, 'null') === 0) {
			return '';
		}
		return $value;
	}

	private static function splitName($name) {
		$name = trim((string)$name);
		if ($name === '') {
			return array('', '');
		}
		$parts = preg_split('/\s+/', $name, 2);
		return array($parts[0], isset($parts[1]) ? $parts[1] : '');
	}

	private static function countryByIso($db, $iso) {
		$iso = strtoupper(trim((string)$iso));
		if (strlen($iso) !== 2) {
			return null;
		}
		$q = $db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE iso_code_2 = '" . $db->escape($iso) . "' AND status = '1' LIMIT 1");
		return $q->num_rows ? $q->row : null;
	}

	private static function resolveZone($db, $country_id, $region) {
		$out = array('zone_id' => 0, 'name' => '');
		$region = trim((string)$region);
		if ($region === '') {
			return $out;
		}
		$q = $db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE country_id = '" . (int)$country_id . "' AND (name = '" . $db->escape($region) . "' OR code = '" . $db->escape($region) . "') AND status = '1' LIMIT 1");
		if ($q->num_rows) {
			$out['zone_id'] = (int)$q->row['zone_id'];
			$out['name'] = $q->row['name'];
		}
		return $out;
	}
}
