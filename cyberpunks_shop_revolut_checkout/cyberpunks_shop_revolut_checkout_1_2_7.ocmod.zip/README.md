# Cyberpunks Shop Revolut Checkout

- **/payment** — classic Revolut **card field** (`revolut_card.cyberpunks.js`)
- **/checkout** express — theme `checkout-revolut-express.js` (Revolut Pay / Apple Pay / Google Pay)
- Adds `redirect_url` when creating Merchant API orders (required for Revolut Pay mobile return)
- **1.2.1** — ships fixed admin PHP/twig that actually register Apple Pay domain and show OK/FAILED after Save
- **1.2.7** — prefer Fast-checkout durable cache over Merchant seeds; name from `shipping.contact`; never let session wipe a persisted street
- **1.2.6** — before status/mail finalize, sync customer name + shipping from Revolut Merchant API (retries) and Fast-checkout cache onto the OC order
- **1.2.5** — skip pushing OC express placeholders (`Express checkout` / `City` / `00000`) as Revolut shipping; keeps Fast-checkout address usable
- **1.2.4** — `finalizeOrder` retries lock races, verifies `order_status_id > 0` before success redirect (fixes Missing Orders + missing confirmation email); `processOrder` accepts Revolut state `completed`

Requires the official **Revolut Gateway for OpenCart** extension (backend).

## Install

1. Build and upload:

```bash
./build-ocmod.sh cyberpunks_shop_revolut_checkout
```

2. OpenCart admin → Extensions → Installer → upload `cyberpunks_shop_revolut_checkout_1_2_7.ocmod.zip`
3. Extensions → Modifications → **Refresh**
4. Keep **Checkout Facade** `1.0.17+` (do not wipe Fast-checkout address with empty session)

## Apple Pay domain (required)

Console `applePay canMakePayment → null` means the domain is **not** registered with Revolut/Apple.

1. Confirm: `https://cyberpunks.shop/.well-known/apple-developer-merchantid-domain-association` → **200**
2. Admin → Extensions → Payments → **Revolut Payment Gateway - Apple Pay / Google Pay**
3. Leave **Status = Disabled** (express buttons are on `/checkout`, not this OC method)
4. Click **Save**
5. Green banner must say **Apple Pay domain: OK** (not FAILED)
6. The form shows Apple Pay domain status (OK / Not registered)

On **iPhone Safari**: Revolut Pay + Apple Pay (no Google Pay — normal).  
On **Mac Safari**: Apple Pay + Google Pay when Wallet/domain are OK.
