<?php
class ControllerExtensionAdvertiseCyberpunksShopMarketing extends Controller {
	private $error = array();
	private $store_id = 0;

	public function __construct($registry) {
		parent::__construct($registry);

		$this->store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;
	}

	public function install() {
		$this->load->model('user/user_group');

		foreach ($this->db->query("SELECT user_group_id FROM `" . DB_PREFIX . "user_group`")->rows as $user_group) {
			$this->model_user_user_group->addPermission($user_group['user_group_id'], 'access', 'extension/advertise/cyberpunks_shop_marketing');
			$this->model_user_user_group->addPermission($user_group['user_group_id'], 'modify', 'extension/advertise/cyberpunks_shop_marketing');
		}

		$this->load->model('setting/extension');

		if (in_array('cyberpunks_shop_marketing', $this->model_setting_extension->getInstalled('module'), true)) {
			$this->model_setting_extension->uninstall('module', 'cyberpunks_shop_marketing');
		}

		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('cyberpunks_shop_marketing');
		$this->model_setting_event->deleteEventByCode('cyberpunks_shop_gtm');
		$this->model_setting_event->deleteEventByCode('analytics_matomo');
		$this->registerCatalogEvents();

		$this->load->model('setting/setting');

		$settings = $this->defaultSettings();
		$this->migrateLegacySettings($settings);

		$this->model_setting_setting->editSetting('advertise_cyberpunks_shop_marketing', $settings, 0);

		$this->model_setting_setting->editSetting('analytics_matomo', array(
			'analytics_matomo_status' => '0',
		), 0);
	}

	public function uninstall() {
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('cyberpunks_shop_marketing');
	}

	public function index() {
		$this->load->language('extension/advertise/cyberpunks_shop_marketing');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');
		$this->load->model('localisation/language');
		$this->ensureCatalogEvents();

		$languages = array();
		foreach ($this->model_localisation_language->getLanguages() as $language) {
			if (empty($language['status'])) {
				continue;
			}

			$languages[] = array(
				'language_id' => (int)$language['language_id'],
				'name'        => $language['name'],
				'code'        => $language['code']
			);
		}
		$data['languages'] = $languages;

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('advertise_cyberpunks_shop_marketing', $this->buildSettingsFromPost(), $this->store_id);

			if (!empty($this->request->post['advertise_cyberpunks_shop_marketing_matomo_status'])) {
				$this->model_setting_setting->editSetting('analytics_matomo', array(
					'analytics_matomo_status' => '0',
				), $this->store_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('extension/advertise/cyberpunks_shop_marketing', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $this->store_id, true));
		}

		$data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';
		$data['error_container_id'] = isset($this->error['container_id']) ? $this->error['container_id'] : '';
		$data['error_consent_expiry_days'] = isset($this->error['consent_expiry_days']) ? $this->error['consent_expiry_days'] : '';
		$data['error_matomo_server'] = isset($this->error['matomo_server']) ? $this->error['matomo_server'] : '';
		$data['error_matomo_site_id'] = isset($this->error['matomo_site_id']) ? $this->error['matomo_site_id'] : '';
		$data['error_meta_pixel_id'] = isset($this->error['meta_pixel_id']) ? $this->error['meta_pixel_id'] : '';
		$data['error_meta_access_token'] = isset($this->error['meta_access_token']) ? $this->error['meta_access_token'] : '';

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('extension/extension/advertise', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/advertise/cyberpunks_shop_marketing', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $this->store_id, true)
		);

		$data['action'] = $this->url->link('extension/advertise/cyberpunks_shop_marketing', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $this->store_id, true);
		$data['cancel'] = $this->url->link('extension/extension/advertise', 'user_token=' . $this->session->data['user_token'], true);

		$localized_fields = $this->localizedTextFields();
		$stored = $this->model_setting_setting->getSetting('advertise_cyberpunks_shop_marketing', $this->store_id);

		foreach ($this->settingFields() as $field) {
			if (isset($this->request->post[$field])) {
				$data[$field] = $this->request->post[$field];
			} elseif (array_key_exists($field, $stored)) {
				$data[$field] = $stored[$field];
			} else {
				$legacy = $this->legacySettingValue($field);
				$data[$field] = ($legacy === null || $legacy === '') ? '' : $legacy;
			}

			if (in_array($field, $localized_fields, true)) {
				$data[$field] = $this->expandLocalizedText($data[$field], $languages);
			}
		}

		if ($data['advertise_cyberpunks_shop_marketing_item_id_field'] === '') {
			$data['advertise_cyberpunks_shop_marketing_item_id_field'] = 'model';
		}

		if ($data['advertise_cyberpunks_shop_marketing_consent_status'] === '' || $data['advertise_cyberpunks_shop_marketing_consent_status'] === null) {
			$data['advertise_cyberpunks_shop_marketing_consent_status'] = 1;
		}

		if ($data['advertise_cyberpunks_shop_marketing_gtm_event_add_to_cart'] === '' || $data['advertise_cyberpunks_shop_marketing_gtm_event_add_to_cart'] === null) {
			$data['advertise_cyberpunks_shop_marketing_gtm_event_add_to_cart'] = 1;
		}

		if ($data['advertise_cyberpunks_shop_marketing_gtm_event_begin_checkout'] === '' || $data['advertise_cyberpunks_shop_marketing_gtm_event_begin_checkout'] === null) {
			$data['advertise_cyberpunks_shop_marketing_gtm_event_begin_checkout'] = 1;
		}

		if ($data['advertise_cyberpunks_shop_marketing_meta_capi_status'] === '' || $data['advertise_cyberpunks_shop_marketing_meta_capi_status'] === null) {
			$data['advertise_cyberpunks_shop_marketing_meta_capi_status'] = 1;
		}

		$stored_token = '';
		if (array_key_exists('advertise_cyberpunks_shop_marketing_meta_access_token', $stored)) {
			$stored_token = trim((string)$stored['advertise_cyberpunks_shop_marketing_meta_access_token']);
		}

		if (isset($this->request->post['advertise_cyberpunks_shop_marketing_meta_access_token'])) {
			$data['advertise_cyberpunks_shop_marketing_meta_access_token'] = trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_meta_access_token']);
		} else {
			$data['advertise_cyberpunks_shop_marketing_meta_access_token'] = $stored_token;
		}

		if ($data['advertise_cyberpunks_shop_marketing_consent_expiry_days'] === '' || $data['advertise_cyberpunks_shop_marketing_consent_expiry_days'] === null) {
			$data['advertise_cyberpunks_shop_marketing_consent_expiry_days'] = 30;
		}

		if ($data['advertise_cyberpunks_shop_marketing_tp_status'] === '' || $data['advertise_cyberpunks_shop_marketing_tp_status'] === null) {
			$data['advertise_cyberpunks_shop_marketing_tp_status'] = 1;
		}

		foreach ($localized_fields as $field) {
			if (!is_array($data[$field])) {
				$data[$field] = $this->expandLocalizedText($data[$field], $languages);
			}
		}

		if (isset($this->session->data['error_warning'])) {
			$data['error_warning'] = $this->session->data['error_warning'];
			unset($this->session->data['error_warning']);
		}

		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_model'] = $this->language->get('text_model');
		$data['text_sku'] = $this->language->get('text_sku');
		$data['text_gtm_section'] = $this->language->get('text_gtm_section');
		$data['text_meta_section'] = $this->language->get('text_meta_section');
		$data['text_consent_section'] = $this->language->get('text_consent_section');
		$data['text_matomo_section'] = $this->language->get('text_matomo_section');
		$data['text_shared_section'] = $this->language->get('text_shared_section');
		$data['text_trustpilot_section'] = $this->language->get('text_trustpilot_section');
		$data['text_setup_hint'] = $this->language->get('text_setup_hint');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_gtm_status'] = $this->language->get('entry_gtm_status');
		$data['entry_container_id'] = $this->language->get('entry_container_id');
		$data['entry_event_purchase'] = $this->language->get('entry_event_purchase');
		$data['entry_event_view_item'] = $this->language->get('entry_event_view_item');
		$data['entry_event_add_to_cart'] = $this->language->get('entry_event_add_to_cart');
		$data['entry_event_begin_checkout'] = $this->language->get('entry_event_begin_checkout');
		$data['entry_meta_capi_status'] = $this->language->get('entry_meta_capi_status');
		$data['entry_meta_pixel_id'] = $this->language->get('entry_meta_pixel_id');
		$data['entry_meta_access_token'] = $this->language->get('entry_meta_access_token');
		$data['entry_meta_test_event_code'] = $this->language->get('entry_meta_test_event_code');
		$data['entry_consent_status'] = $this->language->get('entry_consent_status');
		$data['entry_consent_message'] = $this->language->get('entry_consent_message');
		$data['entry_consent_privacy_label'] = $this->language->get('entry_consent_privacy_label');
		$data['entry_consent_privacy_url'] = $this->language->get('entry_consent_privacy_url');
		$data['entry_consent_deny_label'] = $this->language->get('entry_consent_deny_label');
		$data['entry_consent_grant_label'] = $this->language->get('entry_consent_grant_label');
		$data['entry_consent_expiry_days'] = $this->language->get('entry_consent_expiry_days');
		$data['entry_matomo_status'] = $this->language->get('entry_matomo_status');
		$data['entry_matomo_server'] = $this->language->get('entry_matomo_server');
		$data['entry_matomo_site_id'] = $this->language->get('entry_matomo_site_id');
		$data['entry_matomo_ecommerce'] = $this->language->get('entry_matomo_ecommerce');
		$data['entry_matomo_disable_cookies'] = $this->language->get('entry_matomo_disable_cookies');
		$data['entry_matomo_respect_dnt'] = $this->language->get('entry_matomo_respect_dnt');
		$data['entry_item_id_field'] = $this->language->get('entry_item_id_field');
		$data['entry_tp_status'] = $this->language->get('entry_tp_status');
		$data['entry_tp_score'] = $this->language->get('entry_tp_score');
		$data['entry_tp_stars'] = $this->language->get('entry_tp_stars');
		$data['entry_tp_label'] = $this->language->get('entry_tp_label');
		$data['entry_tp_reviews'] = $this->language->get('entry_tp_reviews');
		$data['entry_tp_url'] = $this->language->get('entry_tp_url');
		$data['entry_tp_sync'] = $this->language->get('entry_tp_sync');
		$data['entry_tp_last_sync'] = $this->language->get('entry_tp_last_sync');
		$data['help_container'] = $this->language->get('help_container');
		$data['help_events'] = $this->language->get('help_events');
		$data['help_no_gtag'] = $this->language->get('help_no_gtag');
		$data['help_meta_capi'] = $this->language->get('help_meta_capi');
		$data['help_meta_pixel_id'] = $this->language->get('help_meta_pixel_id');
		$data['help_meta_access_token'] = $this->language->get('help_meta_access_token');
		$data['help_meta_test_event_code'] = $this->language->get('help_meta_test_event_code');
		$data['help_consent'] = $this->language->get('help_consent');
		$data['help_consent_message'] = $this->language->get('help_consent_message');
		$data['help_consent_privacy'] = $this->language->get('help_consent_privacy');
		$data['help_consent_expiry_days'] = $this->language->get('help_consent_expiry_days');
		$data['help_matomo_server'] = $this->language->get('help_matomo_server');
		$data['help_matomo_site_id'] = $this->language->get('help_matomo_site_id');
		$data['help_matomo_ecommerce'] = $this->language->get('help_matomo_ecommerce');
		$data['help_matomo_disable_cookies'] = $this->language->get('help_matomo_disable_cookies');
		$data['help_matomo_dnt'] = $this->language->get('help_matomo_dnt');
		$data['help_item_id'] = $this->language->get('help_item_id_field');
		$data['help_tp'] = $this->language->get('help_tp');
		$data['help_tp_stars'] = $this->language->get('help_tp_stars');
		$data['help_tp_sync'] = $this->language->get('help_tp_sync');
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_tp_sync'] = $this->language->get('button_tp_sync');
		$data['sync_trustpilot'] = $this->url->link('extension/advertise/cyberpunks_shop_marketing/syncTrustpilot', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $this->store_id, true);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/advertise/cyberpunks_shop_marketing', $data));
	}

	/**
	 * Admin: Sync Trustpilot summary from the saved TrustPilot URL (public page).
	 */
	public function syncTrustpilot() {
		$this->load->language('extension/advertise/cyberpunks_shop_marketing');

		if (!$this->user->hasPermission('modify', 'extension/advertise/cyberpunks_shop_marketing')) {
			$this->session->data['error_warning'] = $this->language->get('error_permission');
			$this->response->redirect($this->url->link('extension/advertise/cyberpunks_shop_marketing', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $this->store_id, true));
			return;
		}

		$this->load->model('setting/setting');
		$this->config->set('config_store_id', $this->store_id);
		$settings = $this->model_setting_setting->getSetting('advertise_cyberpunks_shop_marketing', $this->store_id);

		foreach ($settings as $key => $value) {
			$this->config->set($key, $value);
		}

		$url = isset($settings['advertise_cyberpunks_shop_marketing_tp_url'])
			? trim((string)$settings['advertise_cyberpunks_shop_marketing_tp_url'])
			: '';

		if ($url === '') {
			$this->session->data['error_warning'] = $this->language->get('error_tp_sync_url');
			$this->response->redirect($this->url->link('extension/advertise/cyberpunks_shop_marketing', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $this->store_id, true));
			return;
		}

		if (!class_exists('ModelExtensionAdvertiseCyberpunksShopMarketing', false)) {
			require_once DIR_CATALOG . 'model/extension/advertise/cyberpunks_shop_marketing.php';
		}

		$model = new ModelExtensionAdvertiseCyberpunksShopMarketing($this->registry);
		$result = $model->syncTrustpilotSummary(true);

		if (!empty($result['ok'])) {
			$this->session->data['success'] = $this->language->get('text_tp_sync_success');
		} else {
			$message = isset($result['message']) ? (string)$result['message'] : $this->language->get('error_tp_sync');
			$this->session->data['error_warning'] = $message;
		}

		$this->response->redirect($this->url->link('extension/advertise/cyberpunks_shop_marketing', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $this->store_id, true));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/advertise/cyberpunks_shop_marketing')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!empty($this->request->post['advertise_cyberpunks_shop_marketing_status']) && !empty($this->request->post['advertise_cyberpunks_shop_marketing_gtm_status'])) {
			$container_id = isset($this->request->post['advertise_cyberpunks_shop_marketing_gtm_container_id']) ? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_gtm_container_id']) : '';

			if ($container_id === '' || !preg_match('/^GTM-[A-Z0-9]+$/i', $container_id)) {
				$this->error['container_id'] = $this->language->get('error_container_id');
			}
		}

		if (!empty($this->request->post['advertise_cyberpunks_shop_marketing_status'])
			&& !empty($this->request->post['advertise_cyberpunks_shop_marketing_gtm_status'])
			&& !empty($this->request->post['advertise_cyberpunks_shop_marketing_consent_status'])) {
			$expiry_days = isset($this->request->post['advertise_cyberpunks_shop_marketing_consent_expiry_days'])
				? (int)$this->request->post['advertise_cyberpunks_shop_marketing_consent_expiry_days']
				: 0;

			if ($expiry_days < 1 || $expiry_days > 3650) {
				$this->error['consent_expiry_days'] = $this->language->get('error_consent_expiry_days');
			}
		}

		if (!empty($this->request->post['advertise_cyberpunks_shop_marketing_status']) && !empty($this->request->post['advertise_cyberpunks_shop_marketing_matomo_status'])) {
			$server = isset($this->request->post['advertise_cyberpunks_shop_marketing_matomo_server']) ? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_matomo_server']) : '';

			if ($server === '') {
				$this->error['matomo_server'] = $this->language->get('error_matomo_server');
			} elseif (!filter_var($server, FILTER_VALIDATE_URL)) {
				$this->error['matomo_server'] = $this->language->get('error_matomo_server_url');
			}

			$site_id = isset($this->request->post['advertise_cyberpunks_shop_marketing_matomo_site_id']) ? (int)$this->request->post['advertise_cyberpunks_shop_marketing_matomo_site_id'] : 0;

			if ($site_id < 1) {
				$this->error['matomo_site_id'] = $this->language->get('error_matomo_site_id');
			}
		}

		if (!empty($this->request->post['advertise_cyberpunks_shop_marketing_status'])
			&& !empty($this->request->post['advertise_cyberpunks_shop_marketing_meta_capi_status'])) {
			$pixel_id = isset($this->request->post['advertise_cyberpunks_shop_marketing_meta_pixel_id'])
				? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_meta_pixel_id'])
				: '';

			if ($pixel_id === '' || !preg_match('/^[0-9]{5,}$/', $pixel_id)) {
				$this->error['meta_pixel_id'] = $this->language->get('error_meta_pixel_id');
			}

			$posted_token = isset($this->request->post['advertise_cyberpunks_shop_marketing_meta_access_token'])
				? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_meta_access_token'])
				: '';
			$existing = $this->model_setting_setting->getSetting('advertise_cyberpunks_shop_marketing', $this->store_id);
			$existing_token = isset($existing['advertise_cyberpunks_shop_marketing_meta_access_token'])
				? trim((string)$existing['advertise_cyberpunks_shop_marketing_meta_access_token'])
				: '';

			if ($posted_token === '' && $existing_token === '') {
				$this->error['meta_access_token'] = $this->language->get('error_meta_access_token');
			}
		}

		return !$this->error;
	}

	private function settingFields() {
		return array(
			'advertise_cyberpunks_shop_marketing_status',
			'advertise_cyberpunks_shop_marketing_gtm_status',
			'advertise_cyberpunks_shop_marketing_gtm_container_id',
			'advertise_cyberpunks_shop_marketing_gtm_event_purchase',
			'advertise_cyberpunks_shop_marketing_gtm_event_view_item',
			'advertise_cyberpunks_shop_marketing_gtm_event_add_to_cart',
			'advertise_cyberpunks_shop_marketing_gtm_event_begin_checkout',
			'advertise_cyberpunks_shop_marketing_meta_capi_status',
			'advertise_cyberpunks_shop_marketing_meta_pixel_id',
			'advertise_cyberpunks_shop_marketing_meta_access_token',
			'advertise_cyberpunks_shop_marketing_meta_test_event_code',
			'advertise_cyberpunks_shop_marketing_consent_status',
			'advertise_cyberpunks_shop_marketing_consent_message',
			'advertise_cyberpunks_shop_marketing_consent_privacy_label',
			'advertise_cyberpunks_shop_marketing_consent_privacy_url',
			'advertise_cyberpunks_shop_marketing_consent_deny_label',
			'advertise_cyberpunks_shop_marketing_consent_grant_label',
			'advertise_cyberpunks_shop_marketing_consent_expiry_days',
			'advertise_cyberpunks_shop_marketing_matomo_status',
			'advertise_cyberpunks_shop_marketing_matomo_server',
			'advertise_cyberpunks_shop_marketing_matomo_site_id',
			'advertise_cyberpunks_shop_marketing_matomo_ecommerce',
			'advertise_cyberpunks_shop_marketing_matomo_disable_cookies',
			'advertise_cyberpunks_shop_marketing_matomo_respect_dnt',
			'advertise_cyberpunks_shop_marketing_item_id_field',
			'advertise_cyberpunks_shop_marketing_tp_status',
			'advertise_cyberpunks_shop_marketing_tp_score',
			'advertise_cyberpunks_shop_marketing_tp_stars',
			'advertise_cyberpunks_shop_marketing_tp_label',
			'advertise_cyberpunks_shop_marketing_tp_reviews',
			'advertise_cyberpunks_shop_marketing_tp_bar_5',
			'advertise_cyberpunks_shop_marketing_tp_bar_4',
			'advertise_cyberpunks_shop_marketing_tp_bar_3',
			'advertise_cyberpunks_shop_marketing_tp_bar_2',
			'advertise_cyberpunks_shop_marketing_tp_bar_1',
			'advertise_cyberpunks_shop_marketing_tp_url',
			'advertise_cyberpunks_shop_marketing_tp_business_unit_id',
			'advertise_cyberpunks_shop_marketing_tp_api_key',
			'advertise_cyberpunks_shop_marketing_tp_auto_sync',
			'advertise_cyberpunks_shop_marketing_tp_cron_key',
			'advertise_cyberpunks_shop_marketing_tp_last_sync',
		);
	}

	private function defaultSettings() {
		return array(
			'advertise_cyberpunks_shop_marketing_status'                    => 1,
			'advertise_cyberpunks_shop_marketing_gtm_status'                => 1,
			'advertise_cyberpunks_shop_marketing_gtm_container_id'          => '',
			'advertise_cyberpunks_shop_marketing_gtm_event_purchase'        => 1,
			'advertise_cyberpunks_shop_marketing_gtm_event_view_item'       => 1,
			'advertise_cyberpunks_shop_marketing_gtm_event_add_to_cart'     => 1,
			'advertise_cyberpunks_shop_marketing_gtm_event_begin_checkout'  => 1,
			'advertise_cyberpunks_shop_marketing_meta_capi_status'          => 1,
			'advertise_cyberpunks_shop_marketing_meta_pixel_id'             => '',
			'advertise_cyberpunks_shop_marketing_meta_access_token'         => '',
			'advertise_cyberpunks_shop_marketing_meta_test_event_code'      => '',
			'advertise_cyberpunks_shop_marketing_consent_status'           => 1,
			'advertise_cyberpunks_shop_marketing_consent_message'           => array(),
			'advertise_cyberpunks_shop_marketing_consent_privacy_label'    => array(),
			'advertise_cyberpunks_shop_marketing_consent_privacy_url'      => '',
			'advertise_cyberpunks_shop_marketing_consent_deny_label'      => array(),
			'advertise_cyberpunks_shop_marketing_consent_grant_label'       => array(),
			'advertise_cyberpunks_shop_marketing_consent_expiry_days'      => 30,
			'advertise_cyberpunks_shop_marketing_matomo_status'             => 0,
			'advertise_cyberpunks_shop_marketing_matomo_server'             => '',
			'advertise_cyberpunks_shop_marketing_matomo_site_id'            => 1,
			'advertise_cyberpunks_shop_marketing_matomo_ecommerce'          => 1,
			'advertise_cyberpunks_shop_marketing_matomo_disable_cookies'    => 1,
			'advertise_cyberpunks_shop_marketing_matomo_respect_dnt'        => 0,
			'advertise_cyberpunks_shop_marketing_item_id_field'             => 'model',
			'advertise_cyberpunks_shop_marketing_tp_status'                 => 1,
			'advertise_cyberpunks_shop_marketing_tp_score'                  => '',
			'advertise_cyberpunks_shop_marketing_tp_stars'                  => '',
			'advertise_cyberpunks_shop_marketing_tp_label'                  => '',
			'advertise_cyberpunks_shop_marketing_tp_reviews'                => '',
			'advertise_cyberpunks_shop_marketing_tp_bar_5'                  => '',
			'advertise_cyberpunks_shop_marketing_tp_bar_4'                  => '',
			'advertise_cyberpunks_shop_marketing_tp_bar_3'                  => '',
			'advertise_cyberpunks_shop_marketing_tp_bar_2'                  => '',
			'advertise_cyberpunks_shop_marketing_tp_bar_1'                  => '',
			'advertise_cyberpunks_shop_marketing_tp_url'                    => '',
			'advertise_cyberpunks_shop_marketing_tp_business_unit_id'       => '',
			'advertise_cyberpunks_shop_marketing_tp_api_key'                => '',
			'advertise_cyberpunks_shop_marketing_tp_auto_sync'              => 0,
			'advertise_cyberpunks_shop_marketing_tp_cron_key'               => '',
			'advertise_cyberpunks_shop_marketing_tp_last_sync'              => '',
		);
	}

	private function localizedTextFields() {
		return array(
			'advertise_cyberpunks_shop_marketing_consent_message',
			'advertise_cyberpunks_shop_marketing_consent_privacy_label',
			'advertise_cyberpunks_shop_marketing_consent_deny_label',
			'advertise_cyberpunks_shop_marketing_consent_grant_label',
		);
	}

	/**
	 * Expand stored value into language_id => text for the admin form.
	 */
	private function expandLocalizedText($value, $languages) {
		$map = array();

		foreach ($languages as $language) {
			$map[(int)$language['language_id']] = '';
		}

		if (is_string($value) && $value !== '' && ($value[0] === '{' || $value[0] === '[')) {
			$decoded = json_decode($value, true);

			if (is_array($decoded)) {
				$value = $decoded;
			}
		}

		if (is_array($value)) {
			foreach ($value as $lid => $text) {
				$lid = (int)$lid;

				if (isset($map[$lid])) {
					$map[$lid] = trim((string)$text);
				}
			}

			return $map;
		}

		$legacy = trim((string)$value);

		if ($legacy !== '' && $languages) {
			$map[(int)$languages[0]['language_id']] = $legacy;
		}

		return $map;
	}

	private function normalizeLocalizedText($value) {
		$map = array();

		if (is_array($value)) {
			foreach ($value as $lid => $text) {
				$lid = (int)$lid;
				$text = trim((string)$text);

				if ($lid < 1 || $text === '') {
					continue;
				}

				$map[$lid] = $text;
			}
		} else {
			$text = trim((string)$value);

			if ($text !== '') {
				$map[(int)$this->config->get('config_language_id')] = $text;
			}
		}

		return $map;
	}

	private function buildSettingsFromPost() {
		$existing = $this->model_setting_setting->getSetting('advertise_cyberpunks_shop_marketing', $this->store_id);

		$posted_token = isset($this->request->post['advertise_cyberpunks_shop_marketing_meta_access_token'])
			? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_meta_access_token'])
			: '';

		if ($posted_token === '') {
			$posted_token = isset($existing['advertise_cyberpunks_shop_marketing_meta_access_token'])
				? trim((string)$existing['advertise_cyberpunks_shop_marketing_meta_access_token'])
				: '';
		}

		$preserve = function ($key, $default = '') use ($existing) {
			return array_key_exists($key, $existing) ? $existing[$key] : $default;
		};

		return array(
			'advertise_cyberpunks_shop_marketing_status'                    => !empty($this->request->post['advertise_cyberpunks_shop_marketing_status']) ? 1 : 0,
			'advertise_cyberpunks_shop_marketing_gtm_status'                => !empty($this->request->post['advertise_cyberpunks_shop_marketing_gtm_status']) ? 1 : 0,
			'advertise_cyberpunks_shop_marketing_gtm_container_id'          => isset($this->request->post['advertise_cyberpunks_shop_marketing_gtm_container_id']) ? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_gtm_container_id']) : '',
			'advertise_cyberpunks_shop_marketing_gtm_event_purchase'        => !empty($this->request->post['advertise_cyberpunks_shop_marketing_gtm_event_purchase']) ? 1 : 0,
			'advertise_cyberpunks_shop_marketing_gtm_event_view_item'       => !empty($this->request->post['advertise_cyberpunks_shop_marketing_gtm_event_view_item']) ? 1 : 0,
			'advertise_cyberpunks_shop_marketing_gtm_event_add_to_cart'     => !empty($this->request->post['advertise_cyberpunks_shop_marketing_gtm_event_add_to_cart']) ? 1 : 0,
			'advertise_cyberpunks_shop_marketing_gtm_event_begin_checkout'  => !empty($this->request->post['advertise_cyberpunks_shop_marketing_gtm_event_begin_checkout']) ? 1 : 0,
			'advertise_cyberpunks_shop_marketing_meta_capi_status'          => !empty($this->request->post['advertise_cyberpunks_shop_marketing_meta_capi_status']) ? 1 : 0,
			'advertise_cyberpunks_shop_marketing_meta_pixel_id'             => isset($this->request->post['advertise_cyberpunks_shop_marketing_meta_pixel_id']) ? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_meta_pixel_id']) : '',
			'advertise_cyberpunks_shop_marketing_meta_access_token'         => $posted_token,
			'advertise_cyberpunks_shop_marketing_meta_test_event_code'      => isset($this->request->post['advertise_cyberpunks_shop_marketing_meta_test_event_code']) ? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_meta_test_event_code']) : '',
			'advertise_cyberpunks_shop_marketing_consent_status'            => !empty($this->request->post['advertise_cyberpunks_shop_marketing_consent_status']) ? 1 : 0,
			'advertise_cyberpunks_shop_marketing_consent_message'           => $this->normalizeLocalizedText(isset($this->request->post['advertise_cyberpunks_shop_marketing_consent_message']) ? $this->request->post['advertise_cyberpunks_shop_marketing_consent_message'] : array()),
			'advertise_cyberpunks_shop_marketing_consent_privacy_label'    => $this->normalizeLocalizedText(isset($this->request->post['advertise_cyberpunks_shop_marketing_consent_privacy_label']) ? $this->request->post['advertise_cyberpunks_shop_marketing_consent_privacy_label'] : array()),
			'advertise_cyberpunks_shop_marketing_consent_privacy_url'      => isset($this->request->post['advertise_cyberpunks_shop_marketing_consent_privacy_url']) ? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_consent_privacy_url']) : '',
			'advertise_cyberpunks_shop_marketing_consent_deny_label'       => $this->normalizeLocalizedText(isset($this->request->post['advertise_cyberpunks_shop_marketing_consent_deny_label']) ? $this->request->post['advertise_cyberpunks_shop_marketing_consent_deny_label'] : array()),
			'advertise_cyberpunks_shop_marketing_consent_grant_label'       => $this->normalizeLocalizedText(isset($this->request->post['advertise_cyberpunks_shop_marketing_consent_grant_label']) ? $this->request->post['advertise_cyberpunks_shop_marketing_consent_grant_label'] : array()),
			'advertise_cyberpunks_shop_marketing_consent_expiry_days'      => isset($this->request->post['advertise_cyberpunks_shop_marketing_consent_expiry_days']) ? (int)$this->request->post['advertise_cyberpunks_shop_marketing_consent_expiry_days'] : 30,
			'advertise_cyberpunks_shop_marketing_matomo_status'             => !empty($this->request->post['advertise_cyberpunks_shop_marketing_matomo_status']) ? 1 : 0,
			'advertise_cyberpunks_shop_marketing_matomo_server'             => isset($this->request->post['advertise_cyberpunks_shop_marketing_matomo_server']) ? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_matomo_server']) : '',
			'advertise_cyberpunks_shop_marketing_matomo_site_id'            => isset($this->request->post['advertise_cyberpunks_shop_marketing_matomo_site_id']) ? (int)$this->request->post['advertise_cyberpunks_shop_marketing_matomo_site_id'] : 0,
			'advertise_cyberpunks_shop_marketing_matomo_ecommerce'          => !empty($this->request->post['advertise_cyberpunks_shop_marketing_matomo_ecommerce']) ? 1 : 0,
			'advertise_cyberpunks_shop_marketing_matomo_disable_cookies'      => !empty($this->request->post['advertise_cyberpunks_shop_marketing_matomo_disable_cookies']) ? 1 : 0,
			'advertise_cyberpunks_shop_marketing_matomo_respect_dnt'          => !empty($this->request->post['advertise_cyberpunks_shop_marketing_matomo_respect_dnt']) ? 1 : 0,
			'advertise_cyberpunks_shop_marketing_item_id_field'               => (isset($this->request->post['advertise_cyberpunks_shop_marketing_item_id_field']) && $this->request->post['advertise_cyberpunks_shop_marketing_item_id_field'] === 'sku') ? 'sku' : 'model',
			'advertise_cyberpunks_shop_marketing_tp_status'                   => !empty($this->request->post['advertise_cyberpunks_shop_marketing_tp_status']) ? 1 : 0,
			'advertise_cyberpunks_shop_marketing_tp_score'                    => isset($this->request->post['advertise_cyberpunks_shop_marketing_tp_score']) ? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_tp_score']) : '',
			'advertise_cyberpunks_shop_marketing_tp_stars'                    => isset($this->request->post['advertise_cyberpunks_shop_marketing_tp_stars']) ? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_tp_stars']) : '',
			'advertise_cyberpunks_shop_marketing_tp_label'                    => isset($this->request->post['advertise_cyberpunks_shop_marketing_tp_label']) ? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_tp_label']) : '',
			'advertise_cyberpunks_shop_marketing_tp_reviews'                  => isset($this->request->post['advertise_cyberpunks_shop_marketing_tp_reviews']) && $this->request->post['advertise_cyberpunks_shop_marketing_tp_reviews'] !== ''
				? max(0, (int)$this->request->post['advertise_cyberpunks_shop_marketing_tp_reviews'])
				: '',
			'advertise_cyberpunks_shop_marketing_tp_url'                      => isset($this->request->post['advertise_cyberpunks_shop_marketing_tp_url']) ? trim((string)$this->request->post['advertise_cyberpunks_shop_marketing_tp_url']) : '',
			// Hidden / reserved (not in UI for now) — keep existing values on save.
			'advertise_cyberpunks_shop_marketing_tp_bar_5'                    => $preserve('advertise_cyberpunks_shop_marketing_tp_bar_5', ''),
			'advertise_cyberpunks_shop_marketing_tp_bar_4'                    => $preserve('advertise_cyberpunks_shop_marketing_tp_bar_4', ''),
			'advertise_cyberpunks_shop_marketing_tp_bar_3'                    => $preserve('advertise_cyberpunks_shop_marketing_tp_bar_3', ''),
			'advertise_cyberpunks_shop_marketing_tp_bar_2'                    => $preserve('advertise_cyberpunks_shop_marketing_tp_bar_2', ''),
			'advertise_cyberpunks_shop_marketing_tp_bar_1'                    => $preserve('advertise_cyberpunks_shop_marketing_tp_bar_1', ''),
			'advertise_cyberpunks_shop_marketing_tp_business_unit_id'         => $preserve('advertise_cyberpunks_shop_marketing_tp_business_unit_id', ''),
			'advertise_cyberpunks_shop_marketing_tp_api_key'                  => $preserve('advertise_cyberpunks_shop_marketing_tp_api_key', ''),
			'advertise_cyberpunks_shop_marketing_tp_auto_sync'                => 0,
			'advertise_cyberpunks_shop_marketing_tp_cron_key'                 => $preserve('advertise_cyberpunks_shop_marketing_tp_cron_key', ''),
			'advertise_cyberpunks_shop_marketing_tp_last_sync'                => $preserve('advertise_cyberpunks_shop_marketing_tp_last_sync', ''),
		);
	}

	private function legacySettingValue($field) {
		$legacy = str_replace('advertise_cyberpunks_shop_marketing_', 'module_cyberpunks_shop_marketing_', $field);
		$value = $this->config->get($legacy);

		if ($value !== null && $value !== '') {
			return $value;
		}

		return '';
	}

	private function migrateLegacySettings(array &$settings) {
		$module_map = array(
			'advertise_cyberpunks_shop_marketing_status'                 => 'module_cyberpunks_shop_marketing_status',
			'advertise_cyberpunks_shop_marketing_gtm_status'             => 'module_cyberpunks_shop_marketing_gtm_status',
			'advertise_cyberpunks_shop_marketing_gtm_container_id'       => 'module_cyberpunks_shop_marketing_gtm_container_id',
			'advertise_cyberpunks_shop_marketing_gtm_event_purchase'   => 'module_cyberpunks_shop_marketing_gtm_event_purchase',
			'advertise_cyberpunks_shop_marketing_gtm_event_view_item'  => 'module_cyberpunks_shop_marketing_gtm_event_view_item',
			'advertise_cyberpunks_shop_marketing_matomo_status'        => 'module_cyberpunks_shop_marketing_matomo_status',
			'advertise_cyberpunks_shop_marketing_matomo_server'        => 'module_cyberpunks_shop_marketing_matomo_server',
			'advertise_cyberpunks_shop_marketing_matomo_site_id'       => 'module_cyberpunks_shop_marketing_matomo_site_id',
			'advertise_cyberpunks_shop_marketing_matomo_ecommerce'     => 'module_cyberpunks_shop_marketing_matomo_ecommerce',
			'advertise_cyberpunks_shop_marketing_matomo_disable_cookies' => 'module_cyberpunks_shop_marketing_matomo_disable_cookies',
			'advertise_cyberpunks_shop_marketing_matomo_respect_dnt'   => 'module_cyberpunks_shop_marketing_matomo_respect_dnt',
			'advertise_cyberpunks_shop_marketing_item_id_field'        => 'module_cyberpunks_shop_marketing_item_id_field',
		);

		foreach ($module_map as $new_key => $old_key) {
			$value = $this->config->get($old_key);
			if ($value !== null && $value !== '') {
				$settings[$new_key] = $value;
			}
		}

		$gtm_container = $this->config->get('module_cyberpunks_shop_gtm_container_id');
		if ($gtm_container !== null && trim((string)$gtm_container) !== '') {
			$settings['advertise_cyberpunks_shop_marketing_gtm_container_id'] = trim((string)$gtm_container);
			$settings['advertise_cyberpunks_shop_marketing_gtm_status'] = (int)$this->config->get('module_cyberpunks_shop_gtm_status');
			$settings['advertise_cyberpunks_shop_marketing_gtm_event_purchase'] = (int)$this->config->get('module_cyberpunks_shop_gtm_event_purchase');
			$settings['advertise_cyberpunks_shop_marketing_gtm_event_view_item'] = (int)$this->config->get('module_cyberpunks_shop_gtm_event_view_item');
			if ($this->config->get('module_cyberpunks_shop_gtm_item_id_field') === 'sku') {
				$settings['advertise_cyberpunks_shop_marketing_item_id_field'] = 'sku';
			}
		}

		$matomo_server = $this->config->get('analytics_matomo_server');
		if ($matomo_server !== null && trim((string)$matomo_server) !== '') {
			$settings['advertise_cyberpunks_shop_marketing_matomo_server'] = trim((string)$matomo_server);
			$settings['advertise_cyberpunks_shop_marketing_matomo_site_id'] = (int)$this->config->get('analytics_matomo_site_id');
			$settings['advertise_cyberpunks_shop_marketing_matomo_status'] = (int)$this->config->get('analytics_matomo_status');
			$settings['advertise_cyberpunks_shop_marketing_matomo_ecommerce'] = (int)$this->config->get('analytics_matomo_ecommerce');
			$settings['advertise_cyberpunks_shop_marketing_matomo_disable_cookies'] = (int)$this->config->get('analytics_matomo_disable_cookies');
			$settings['advertise_cyberpunks_shop_marketing_matomo_respect_dnt'] = (int)$this->config->get('analytics_matomo_respect_dnt');
			if ($this->config->get('analytics_matomo_sku_field') === 'sku') {
				$settings['advertise_cyberpunks_shop_marketing_item_id_field'] = 'sku';
			}
		}
	}

	private function registerCatalogEvents() {
		$this->load->model('setting/event');
		$this->model_setting_event->addEvent('cyberpunks_shop_marketing', 'catalog/controller/checkout/success/before', 'extension/advertise/cyberpunks_shop_marketing/captureSuccess', 1, 0);
		$this->model_setting_event->addEvent('cyberpunks_shop_marketing', 'catalog/controller/checkout/success/after', 'extension/advertise/cyberpunks_shop_marketing/injectSuccess', 1, 1);
		$this->model_setting_event->addEvent('cyberpunks_shop_marketing', 'catalog/controller/product/product/before', 'extension/advertise/cyberpunks_shop_marketing/captureViewItem', 1, 0);
		$this->model_setting_event->addEvent('cyberpunks_shop_marketing', 'catalog/controller/product/product/after', 'extension/advertise/cyberpunks_shop_marketing/injectViewItem', 1, 1);
		$this->model_setting_event->addEvent('cyberpunks_shop_marketing', 'catalog/controller/checkout/checkout/before', 'extension/advertise/cyberpunks_shop_marketing/captureBeginCheckout', 1, 0);
		$this->model_setting_event->addEvent('cyberpunks_shop_marketing', 'catalog/controller/checkout/checkout/after', 'extension/advertise/cyberpunks_shop_marketing/injectBeginCheckout', 1, 1);
		$this->model_setting_event->addEvent('cyberpunks_shop_marketing', 'catalog/view/product/product/before', 'extension/advertise/cyberpunks_shop_marketing/prepareProductView', 1, 0);
	}

	/**
	 * Register missing catalog events without wiping existing ones (upgrade path).
	 */
	private function ensureCatalogEvents() {
		$this->load->model('setting/event');

		$required = array(
			'catalog/controller/checkout/success/before' => 'extension/advertise/cyberpunks_shop_marketing/captureSuccess',
			'catalog/controller/checkout/success/after'  => 'extension/advertise/cyberpunks_shop_marketing/injectSuccess',
			'catalog/controller/product/product/before'  => 'extension/advertise/cyberpunks_shop_marketing/captureViewItem',
			'catalog/controller/product/product/after'   => 'extension/advertise/cyberpunks_shop_marketing/injectViewItem',
			'catalog/controller/checkout/checkout/before' => 'extension/advertise/cyberpunks_shop_marketing/captureBeginCheckout',
			'catalog/controller/checkout/checkout/after'  => 'extension/advertise/cyberpunks_shop_marketing/injectBeginCheckout',
			'catalog/view/product/product/before'         => 'extension/advertise/cyberpunks_shop_marketing/prepareProductView',
		);

		$existing = array();
		$query = $this->db->query("SELECT `trigger`, `action` FROM `" . DB_PREFIX . "event` WHERE `code` = 'cyberpunks_shop_marketing'");

		foreach ($query->rows as $row) {
			$existing[$row['trigger'] . '|' . $row['action']] = true;
		}

		foreach ($required as $trigger => $action) {
			$key = $trigger . '|' . $action;

			if (isset($existing[$key])) {
				continue;
			}

			$this->model_setting_event->addEvent('cyberpunks_shop_marketing', $trigger, $action, 1, strpos($trigger, '/after') !== false ? 1 : 0);
		}
	}
}
